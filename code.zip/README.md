# 论文代码支撑材料

## 目录
- scripts/：数据处理、三道题、消费者分析、绘图与论文生成。
- prediction-models/scripts/：问题一的五折调参与基线评估。
- data/processed/nightly/overnight-q123-20261030/：问题二、三补充验证。
- tests/、tests_q1/、prediction-models/tests/：对应检查代码。
- requirements.lock.txt：论文分析依赖。
- prediction-models/requirements-tabpfn.txt：TabPFN实验依赖。
- docs/：字段字典与文献清单。
- MANIFEST.json：文件清单和SHA256。

## 运行顺序
在解压后的项目根目录运行，各脚本的参数见 --help。
将赛题附件放在 data/raw/，训练/测试划分放在 data/splits/seed_0/。
prediction-models/ 是独立实验项目，准备相同的 data/raw/ 与 data/splits/seed_0/。

1. 数据：
   python scripts/build_data_contract.py
   python scripts/audit_scale.py
2. 问题一基础模型：
   python scripts/q1_pipeline.py
   实验项目中的 paper_baselines.py、tune_rf.py、tune_tabpfn.py、
   tune_multitask.py 负责调参，finalize_tuning.py 负责完整训练和留出评估。
3. 最终TabPFN：
   python scripts/q1_final_tabpfn.py --experiment-root prediction-models --model-path ../pretrained/Prior-Labstabpfn_3_5/tabpfn-v3.5-20260909.safetensors
   输出在 prediction-models/results/tabpfn_final_seed_0/。
   参数为4个估计器、温度1、先平均后softmax、seed 0；训练上下文按原顺序重复两次。
   采用原实验的五折划分，输出175款啤酒的OOF预测及75款留出预测。
   import_q1_tabpfn_final.py为既有实验归档的论文结果导入脚本；
   独立入口产生的 comparison.csv、oof_predictions.csv 和 test/test_predictions.csv 可直接核对最终模型。
4. 问题二：
   python scripts/q2_graph.py
   python scripts/q2_evidence.py
   python scripts/q2_stability.py --bootstrap-b 200
   补充验证：nightly目录下q2/q2_robustness_audit.py，参数 --repo-root . --output-dir <输出目录>。
5. 问题三：
   python scripts/q3_generate.py
   python scripts/q3_transfer.py
   python scripts/q3_sensory_profile.py
   补充验证：nightly目录下q3/q3_bounded_validation.py。
6. 消费者、价格与剂量响应：
   python scripts/q4_consumer.py
7. 图表与论文：
   各题 *_figures.py、q1_final_r2_figures.py 生成图表；
   build_paper.py 生成修订稿，docx_to_pdf_word.ps1 负责Word转PDF。

原始附件、模型权重、训练产物和论文模板需在本地准备。
