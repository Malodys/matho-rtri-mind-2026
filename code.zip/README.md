# 论文代码支撑材料

## 目录
- scripts/：数据处理、问题一至三、消费者与价格分析、绘图和论文生成。
- prediction-models/scripts/：问题一模型训练、五折调参和留出集评估。
- tests/、tests_q1/、prediction-models/tests/：相应检查代码。
- data/processed/nightly/overnight-q123-20261030/：问题二置换检验及FDR校正、问题三留出生成验证。
- requirements.lock.txt：论文分析环境依赖。
- prediction-models/requirements-tabpfn.txt：问题一TabPFN实验依赖。
- docs/：字段字典和论文参考文献清单。
- MANIFEST.json：压缩包内文件及SHA256。

## 论文与代码对应
1. 数据核对：scripts/data_contract.py、audit_scale.py、resolve_corr_type.py、split_dataset.py。
2. 感官预测：scripts/q1_pipeline.py及q1_models.py；prediction-models/scripts/中的
   tuning_protocol.py、paper_baselines.py、tune_tabpfn.py、tune_multitask.py、finalize_tuning.py。
3. 最终TabPFN采用每条训练样本均匀重复两次的上下文。对应实现位于
   prediction-models/scripts/run_debias.py的tabpfn_context_uniform配置；
   retained_context由debias_weights.py提供。论文使用该均匀上下文结果。
   scripts/import_q1_tabpfn_final.py负责核对、导入最终预测并生成论文使用的指标及评分。
4. 关键化合物：scripts/q2_graph.py、q2_evidence.py、q2_stability.py、q2_chem_kb.py；
   留出验证为nightly目录下q2/q2_robustness_audit.py。
5. 风格生成与迁移：scripts/q3_copula.py、q3_generate.py、q3_transfer.py、q3_sensory_profile.py；
   留出验证为nightly目录下q3/q3_bounded_validation.py。
6. 消费者、价格和剂量响应：scripts/q4_consumer.py。
7. 图表和论文：各题*_figures.py、scripts/plot_style.py、q1_final_r2_figures.py、
   build_paper.py、paper_prose.py、docx_to_pdf_word.ps1。

## 使用
将scripts/等目录放到论文项目根目录；prediction-models/作为独立实验项目使用，
准备其data/raw/与data/splits/seed_0/。原始附件与预训练权重由本地提供。
主项目与实验项目分别使用各自依赖。训练脚本参数见各脚本--help。
导入最终问题一结果时，在主项目运行：
python scripts/import_q1_tabpfn_final.py --experiment-root prediction-models

本包收录源程序、依赖清单与必要文档；数据、模型权重和实验输出另行提供。
