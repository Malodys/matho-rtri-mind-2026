import sys
import unittest
from pathlib import Path
import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from causal_screen import (Settings, analyse, conditional_scores, dependence_matrix,
                           gaussian_ranks, local_blanket, stable_subset)
from run_causal_screen import predict_selected


class ConditionalSelectionTests(unittest.TestCase):
    def test_observed_ranks_and_missing_cells_leave_source_unchanged(self):
        x = np.array([[1., np.nan], [2., 3.], [3., 3.]])
        before = x.copy()
        result = gaussian_ranks(x)
        np.testing.assert_equal(x, before)
        self.assertTrue(np.isfinite(result).all())
        self.assertEqual(result[0, 1], 0.)
        self.assertTrue(np.all(np.diff(result[:, 0]) > 0))

    def test_conditioning_removes_association_of_a_correlated_proxy(self):
        rng = np.random.default_rng(0)
        cause = rng.normal(size=3000)
        x = np.column_stack((cause, cause + .7 * rng.normal(size=3000), rng.normal(size=3000)))
        y = (2 * cause + rng.normal(size=3000))[:, None]
        corr, rank = dependence_matrix(x, y)
        marginal, _ = conditional_scores(corr, 3, [], len(x), rank, 3)
        partial, probability = conditional_scores(corr, 3, [0], len(x), rank, 3)
        self.assertGreater(marginal[1], .6)
        self.assertLess(abs(partial[1]), .06)
        self.assertGreater(probability[1], .01)
        selected, _ = local_blanket(corr, 3, 3, len(x), rank, Settings(alpha=.001))
        self.assertEqual(selected, [0])

    def test_style_adjustment_removes_group_only_association(self):
        rng = np.random.default_rng(21)
        styles = np.repeat(np.arange(5), 300)
        x = (styles * 3 + rng.normal(size=len(styles)))[:, None]
        y = (styles * 3 + rng.normal(size=len(styles)))[:, None]
        corr, _ = dependence_matrix(x, y)
        adjusted, rank = dependence_matrix(x, y, styles)
        self.assertGreater(corr[0, 1], .8)
        self.assertLess(abs(adjusted[0, 1]), .06)
        self.assertEqual(rank, 5)

    def test_constant_target_has_no_stable_evidence_and_explicit_fallback(self):
        rng = np.random.default_rng(3)
        x = pd.DataFrame(rng.normal(size=(60, 3)), columns=['a', 'b', 'esters_sum'])
        y = pd.DataFrame({'score': np.ones(60)})
        report, selections, audit = analyse(x, y, ['one']*60, Settings(bootstraps=4))
        self.assertEqual(audit['eligible_features'], 2)
        self.assertTrue((report['frequency'] == 0).all())
        self.assertTrue(report['selection_fallback'].all())
        self.assertTrue((report['evidence'] == 'unstable').all())
        self.assertEqual(len(selections['score']['conditional']), 1)
        self.assertNotIn('esters_sum', selections['score']['conditional'])

    def test_other_unknown_sensory_targets_cannot_change_selection(self):
        rng = np.random.default_rng(4)
        x = pd.DataFrame(rng.normal(size=(120, 5)), columns=list('abcde'))
        y = pd.DataFrame({'one': x.a + .1*rng.normal(size=120), 'two': x.b})
        cfg = Settings(bootstraps=4)
        first, first_sets, _ = analyse(x, y, ['s']*120, cfg)
        changed = y.copy()
        changed['two'] = rng.normal(size=120)*1000
        second, second_sets, _ = analyse(x, changed, ['s']*120, cfg)
        self.assertEqual(first_sets['one'], second_sets['one'])
        pd.testing.assert_frame_equal(first[first.target == 'one'], second[second.target == 'one'])

    def test_matched_controls_use_exactly_the_same_feature_count(self):
        rng = np.random.default_rng(5)
        x = pd.DataFrame(rng.normal(size=(150, 6)), columns=list('abcdef'))
        y = pd.DataFrame({'score': x.a + x.b + .2*rng.normal(size=150)})
        report, selections, _ = analyse(x, y, ['s']*150, Settings(bootstraps=8))
        sets = selections['score']
        self.assertEqual(len(sets['conditional']), len(sets['marginal_matched']))
        self.assertEqual(len(sets['style_conditional']), len(sets['marginal_style_matched']))
        self.assertTrue(report['frequency'].between(0, 1).all())
        self.assertEqual(len(sets['conditional']), len(set(sets['conditional'])))

    def test_prediction_batches_respect_each_targets_input_selection(self):
        x = pd.DataFrame({'a': [1., 2., 3.], 'b': [4., 5., 6.]})
        y = pd.DataFrame({'one': [10., 20., 30.], 'two': [1., 2., 3.]})
        selections = {'one': {'conditional': ['a']}, 'two': {'conditional': ['a', 'b']}}
        class Model:
            def predict_batched(self, train, target, valid):
                assert len({frame.shape for frame in train}) == 1
                for frame, response in zip(train, target):
                    assert list(frame.columns) == (['a'] if response.name == 'one' else ['a', 'b'])
                return [np.repeat(t.mean(), len(v)) for t, v in zip(target, valid)]
        prediction = predict_selected(Model(), x, y, x.iloc[:2], selections, 'conditional', [0, 1])
        np.testing.assert_equal(prediction, [[20., 2.], [20., 2.]])

    def test_no_stability_support_never_silently_returns_empty_inputs(self):
        ids, fallback = stable_subset(np.zeros(3), np.array([.1, -.9, .2]), Settings())
        self.assertTrue(fallback)
        self.assertEqual(ids.tolist(), [1])


    def test_five_fold_selection_never_receives_validation_rows(self):
        from argparse import Namespace
        from tempfile import mkdtemp
        from unittest.mock import patch
        from sklearn.model_selection import KFold
        import run_causal_screen as pipeline

        root = Path(mkdtemp(dir=Path(__file__).resolve().parents[1] / 'tmp'))
        old = root / 'results/tuned_seed_0/tabpfn'
        old.mkdir(parents=True)
        n = 50
        x = pd.DataFrame({'a': np.arange(n, dtype=float), 'b': np.arange(n, dtype=float)**2})
        y = pd.DataFrame({'score': np.arange(n, dtype=float)/10})
        metadata = pd.DataFrame({'beer': np.arange(n), 'tasting_category_fine': ['s']*n})
        folds = list(KFold(5).split(x))
        identity = {key: 'test' for key in ['dataset_sha256','checkpoint_sha256','python','tabpfn','torch','device']}
        pd.Series({**identity,'status':'completed'},name='value').rename_axis('setting').to_csv(old/'run.csv')
        pd.Series({'trial':0},name='value').rename_axis('parameter').to_csv(old/'best_parameters.csv')
        np.save(old/'cv_predictions.npy',np.zeros((1,n,1)))
        chosen = {'score': {method: ['a'] for method in pipeline.METHODS}}
        seen = []
        def select(output, train_x, train_y, train_meta, settings, labels):
            assert train_x.index.equals(train_y.index)
            assert train_x.index.equals(train_meta.index)
            seen.append(set(train_meta.beer))
            return chosen
        class Model:
            def __init__(self, **kwargs):
                pass
            def predict_batched(self, xx, yy, vv):
                return [np.full(len(v), response.mean()) for response,v in zip(yy,vv)]
        args = Namespace(data_dir=root,output_dir=root/'out',model_path=root/'model',
                         seed=0,device='test',settings=Settings(bootstraps=2),stage='all',batch_size=4)
        with patch.object(pipeline,'PROJECT',root), patch.object(pipeline,'load_protocol',return_value=(x,y,metadata,folds)), \
             patch.object(pipeline,'read_parameters',return_value={}), patch.object(pipeline,'frozen_settings',return_value=identity), \
             patch.object(pipeline,'feature_labels',return_value={}), patch.object(pipeline,'export_input_network'), patch.object(pipeline,'summarize_evidence'), \
             patch.object(pipeline,'analyse_cached',side_effect=select), patch('tabpfn.TabPFNRegressor',Model):
            pipeline.run(args)
        self.assertEqual(seen[0],set(range(n)))
        self.assertEqual(len(seen),6)
        for observed,(train,valid) in zip(seen[1:],folds):
            self.assertEqual(observed,set(train))
            self.assertTrue(observed.isdisjoint(valid))


if __name__ == '__main__':
    unittest.main()
