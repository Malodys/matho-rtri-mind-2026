import sys
import tempfile
import unittest
from contextlib import redirect_stdout
from io import StringIO
from pathlib import Path

import networkx as nx
import numpy as np
import pandas as pd
from causallearn.search.ConstraintBased.FCI import fci
from causallearn.utils.cit import MV_FisherZ

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from causal_structure import (CachedMissingFisherZ, SearchBudgetExceeded, build_joint,
                              edge_interpretation, observed_gaussian_ranks, prior_audit)


class CausalStructureTests(unittest.TestCase):
    def test_all_inputs_and_all_targets_are_retained_in_the_joint_graph(self):
        x=pd.DataFrame({'a':[1.,2.], 'esters_sum':[2.,3.]})
        y=pd.DataFrame({'score':[3.,4.], 'other':[5.,6.]})
        frame=build_joint(x,y)
        self.assertEqual(frame.shape,(2,4))
        self.assertEqual(list(frame),['chemical:a','chemical:esters_sum','sensory:score','sensory:other'])

    def test_rank_transform_preserves_missingness_and_does_not_change_source(self):
        frame=pd.DataFrame({'a':[1.,np.nan,3.],'b':[2.,4.,6.]})
        original=frame.copy(deep=True)
        transformed=observed_gaussian_ranks(frame)
        pd.testing.assert_frame_equal(frame,original)
        np.testing.assert_array_equal(np.isnan(transformed),frame.isna())
        self.assertTrue(np.isfinite(transformed[~np.isnan(transformed)]).all())

    def test_cached_test_matches_library_testwise_deletion(self):
        rng=np.random.default_rng(1)
        data=rng.normal(size=(150,5))
        data[::13,2]=np.nan
        tested=CachedMissingFisherZ(data)
        reference=MV_FisherZ(data)
        try:
            for a,b,s in [(0,1,[]),(0,1,[2]),(1,4,[0,2,3])]:
                self.assertAlmostEqual(tested(a,b,s),reference(a,b,s),places=12)
        finally:
            tested.close()

    def test_persistent_cache_rejects_changed_data(self):
        root=Path(tempfile.mkdtemp(dir=Path(__file__).resolve().parents[1]/'tmp'))
        data=np.random.default_rng(2).normal(size=(40,3))
        test=CachedMissingFisherZ(data,sqlite_path=root/'tests.sqlite')
        first=test(0,1,[2])
        test.close()
        resumed=CachedMissingFisherZ(data,sqlite_path=root/'tests.sqlite')
        self.assertEqual(resumed(0,1,[2]),first)
        self.assertEqual(resumed.new_tests,0)
        resumed.close()
        changed=data.copy()
        changed[0,0]+=1
        with self.assertRaisesRegex(ValueError,'differs'):
            CachedMissingFisherZ(changed,sqlite_path=root/'tests.sqlite')

    def test_budget_never_fabricates_an_independence_result(self):
        data=np.random.default_rng(3).normal(size=(40,3))
        test=CachedMissingFisherZ(data,max_tests=1)
        try:
            test(0,1)
            with self.assertRaises(SearchBudgetExceeded):
                test(0,2)
        finally:
            test.close()

    def test_temporal_prior_does_not_erase_hidden_confounding_ambiguity(self):
        self.assertEqual(edge_interpretation(2,1),'causal_path_or_latent_confounding_unresolved')
        self.assertIn('other_endpoint_stays_unresolved',prior_audit('chemical','sensory',2,2))
        self.assertIn('conflicts',prior_audit('chemical','sensory',1,-1))
        self.assertEqual(edge_interpretation(1,1),'latent_common_cause_compatible')

    def test_library_oracle_keeps_the_known_latent_confounding_ambiguity(self):
        # Exact d-separation in a specified toy DAG tests graph semantics, not beer data.
        dag=nx.DiGraph([(0,1),(0,3),(4,1),(4,3),(1,2),(2,3)])
        with redirect_stdout(StringIO()):
            graph,_=fci(np.zeros((100,4)),independence_test_method='d_separation',
                        true_dag=dag,show_progress=False,node_names=['X','Z','Q','Y'])
        self.assertEqual(graph.graph[1,3],2)
        self.assertEqual(graph.graph[3,1],1)


    def test_mediated_paths_are_distinguished_from_direct_adjacency(self):
        from causal_path_audit import relation_reachability
        matrix=np.array([[0,-1,0],[1,0,-1],[0,1,0]])
        reached,possible,distance,_=relation_reachability(matrix)
        self.assertEqual(matrix[0,2],0)
        self.assertTrue(reached[0,2])
        self.assertEqual(distance[0,2],2)
        self.assertFalse(reached[2,0])

    def test_bidirected_ancestral_path_is_flagged_even_without_directed_cycles(self):
        from causal_graph_stability import ancestry_checks
        matrix=np.array([[0,-1,1],[1,0,-1],[1,1,0]])
        self.assertFalse(ancestry_checks(matrix))

    def test_tetrad_temporal_prior_preserves_the_oracle_latent_ambiguity(self):
        from tetrad_runtime import start_tetrad
        start_tetrad()
        from jpype import JClass
        from pytetrad.tools.translate import tetrad_graph_to_causal_learn
        node=JClass('edu.cmu.tetrad.graph.GraphNode')
        dag=JClass('edu.cmu.tetrad.graph.EdgeListGraph')()
        nodes={name:node(name) for name in ['X','Z','Q','Y','U']}
        nodes['U'].setNodeType(JClass('edu.cmu.tetrad.graph.NodeType').LATENT)
        for item in nodes.values(): dag.addNode(item)
        for a,b in [('X','Z'),('X','Y'),('U','Z'),('U','Y'),('Z','Q'),('Q','Y')]:
            dag.addDirectedEdge(nodes[a],nodes[b])
        test=JClass('edu.cmu.tetrad.search.test.MsepTest')(dag)
        algorithm=JClass('edu.cmu.tetrad.search.Rfci')(test)
        knowledge=JClass('edu.cmu.tetrad.data.Knowledge')()
        for name in ['X','Z','Q']: knowledge.addToTier(0,name)
        knowledge.addToTier(1,'Y')
        algorithm.setKnowledge(knowledge)
        graph=tetrad_graph_to_causal_learn(algorithm.search())
        index={n.get_name():i for i,n in enumerate(graph.get_nodes())}
        self.assertEqual(graph.graph[index['Z'],index['Y']],2)
        self.assertEqual(graph.graph[index['Y'],index['Z']],1)


if __name__=='__main__':
    unittest.main()
