import sys
import unittest
from pathlib import Path

import numpy as np
import torch
from sklearn.model_selection import train_test_split

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from debias_weights import (WeightSettings, blend_weights, covariance_balance, effective_sample_size,
                           feature_map, learn_weights, retained_context, WeightFactory)
from multitask_cv import fit_member


class DebiasTests(unittest.TestCase):
    def test_covariance_loss_excludes_only_same_variable_blocks(self):
        mapped=torch.tensor(np.random.default_rng(0).normal(size=(25,4,3)),dtype=torch.float64)
        weights=torch.arange(1,26,dtype=torch.float64)
        flat=mapped.reshape(25,-1)
        p=weights/weights.sum()
        mean=(flat*p[:,None]).sum(0)
        covariance=flat.T@(flat*p[:,None])-mean[:,None]*mean[None,:]
        desired=0.
        for a in range(4):
            for b in range(4):
                if a!=b:
                    desired+=covariance[a*3:(a+1)*3,b*3:(b+1)*3].square().sum().item()
        self.assertAlmostEqual(covariance_balance(mapped,weights).item(),desired/(4*3*9),places=12)

    def test_feature_map_keeps_all_columns_and_source_values(self):
        x=np.array([[1.,2.,np.nan],[2.,4.,5.],[3.,6.,7.]])
        before=x.copy()
        phi=feature_map(x)
        self.assertEqual(phi.shape,(3,3,3))
        self.assertTrue(np.isfinite(phi).all())
        np.testing.assert_equal(x,before)

    def test_positive_bounded_weights_preserve_effective_sample_size(self):
        rng=np.random.default_rng(1)
        x=rng.normal(size=(100,5))
        x[:75,1]=x[:75,0]+.2*rng.normal(size=75)
        original=x.copy()
        w,diagnostics=learn_weights(x,WeightSettings(steps=100))
        self.assertEqual(w.shape,(100,))
        self.assertTrue(np.isfinite(w).all())
        self.assertGreaterEqual(w.min(),.1-1e-8)
        self.assertLessEqual(w.max(),5+1e-8)
        self.assertGreaterEqual(effective_sample_size(w),80-1e-6)
        self.assertLessEqual(diagnostics['balance_after'],diagnostics['balance_before']+1e-8)
        self.assertLess(diagnostics['balance_after'],diagnostics['balance_before']*.999)
        np.testing.assert_equal(x,original)

    def test_context_keeps_every_original_row_and_exactly_doubles_count(self):
        weights=np.array([.1,.5,1.,2.,1.4])
        rows,counts=retained_context(weights)
        self.assertEqual(len(rows),10)
        self.assertTrue((counts>=1).all())
        np.testing.assert_array_equal(rows[:5],np.arange(5))
        uniform,counts_uniform=retained_context(np.ones(5))
        np.testing.assert_array_equal(counts_uniform,np.repeat(2,5))
        np.testing.assert_array_equal(uniform,np.tile(np.arange(5),2))

    def test_strength_zero_and_uniform_loss_reproduce_unweighted_training(self):
        x=np.random.default_rng(2).normal(size=(40,3))
        y=np.column_stack((x[:,0],x[:,1]))
        kwargs=dict(seed=5,device='cpu',hidden=(8,4),dropout=0.,max_epochs=8,patience=3)
        original,xs,ys,_=fit_member(x,y,**kwargs)
        weighted,xw,yw,_=fit_member(x,y,sample_weight_factory=lambda values:np.ones(len(values)),**kwargs)
        with torch.no_grad():
            a=ys.inverse_transform(original(torch.tensor(xs.transform(x))).numpy())
            b=yw.inverse_transform(weighted(torch.tensor(xw.transform(x))).numpy())
        np.testing.assert_allclose(a,b,rtol=1e-5,atol=1e-6)
        np.testing.assert_array_equal(blend_weights(np.array([.5,1.5]),0),np.ones(2))

    def test_early_stopping_weights_use_only_inner_training_rows_then_full_refit(self):
        x=np.random.default_rng(3).normal(size=(40,3))
        x[:,0]=np.arange(40)
        y=np.column_stack((x[:,1],x[:,2]))
        calls=[]
        def factory(values):
            calls.append(values.copy())
            return np.ones(len(values))
        fit_member(x,y,seed=7,device='cpu',hidden=(8,4),dropout=0.,
                   max_epochs=3,patience=2,sample_weight_factory=factory)
        inner,stop=train_test_split(np.arange(40),test_size=.2,random_state=7)
        self.assertEqual(len(calls),2)
        np.testing.assert_array_equal(calls[0],x[inner])
        np.testing.assert_array_equal(calls[1],x)
        self.assertTrue(set(calls[0][:,0]).isdisjoint(x[stop,0]))

    def test_factory_has_no_target_or_evaluation_data_argument(self):
        import inspect
        self.assertEqual(list(inspect.signature(WeightFactory.__call__).parameters),['self','features','strength'])
        with self.assertRaises(ValueError):
            retained_context(np.array([1.,-1.]))


    def test_strength_is_frozen_from_training_cv_before_holdout_evaluation(self):
        from tempfile import mkdtemp
        import pandas as pd
        from run_debias import freeze_strengths
        output=Path(mkdtemp(dir=Path(__file__).resolve().parents[1]/'tmp'))
        table=pd.DataFrame([
            {'family':'tabpfn','method':'tabpfn_original','strength':0.,'mean_cv_r2':.5},
            {'family':'tabpfn','method':'tabpfn_weight_half','strength':.5,'mean_cv_r2':.2},
            {'family':'tabpfn','method':'tabpfn_weight_full','strength':1.,'mean_cv_r2':.1},
            {'family':'multitask','method':'multitask_weight_half','strength':.5,'mean_cv_r2':.1},
            {'family':'multitask','method':'multitask_weight_full','strength':1.,'mean_cv_r2':.2},
        ])
        expected={'dataset_sha256':'train','weight_source_sha256':'weights'}
        chosen=freeze_strengths(output,table,expected)
        self.assertEqual(chosen.method.tolist(),['tabpfn_weight_half','multitask_weight_full'])
        changed=table.copy()
        changed.loc[changed.method=='tabpfn_weight_full','mean_cv_r2']=.9
        with self.assertRaises(AssertionError):
            freeze_strengths(output,changed,expected)


if __name__=='__main__':
    unittest.main()
