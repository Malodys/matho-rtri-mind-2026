from __future__ import annotations

import argparse
from dataclasses import asdict
import hashlib
from importlib.metadata import version
from pathlib import Path
import platform
from time import perf_counter

import numpy as np
import pandas as pd
import torch

from debias_weights import WeightFactory, WeightSettings, effective_sample_size, retained_context
from finalize_tuning import read_parameters
from multitask_cv import fit_member
from tabpfn_cv import PROJECT, load_split, project_path
from tune_tabpfn import fit_predict as tabpfn_predict
from tuning_protocol import data_signature, export_predictions, load_protocol, macro_scores, make_store

CONFIGS=[
    {'method':'tabpfn_original','family':'tabpfn','strength':0.,'context':'original'},
    {'method':'tabpfn_context_uniform','family':'tabpfn','strength':0.,'context':'doubled'},
    {'method':'tabpfn_weight_half','family':'tabpfn','strength':.5,'context':'doubled'},
    {'method':'tabpfn_weight_full','family':'tabpfn','strength':1.,'context':'doubled'},
    {'method':'multitask_original','family':'multitask','strength':0.,'context':'original'},
    {'method':'multitask_weight_half','family':'multitask','strength':.5,'context':'weighted_loss'},
    {'method':'multitask_weight_full','family':'multitask','strength':1.,'context':'weighted_loss'},
]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def settings(args,x,y,metadata,parameters):
    return {
        'dataset_sha256':data_signature(x,y,metadata),'checkpoint_sha256':sha(args.model_path),
        'python':platform.python_version(),'torch':torch.__version__,'tabpfn':version('tabpfn'),
        'numpy':version('numpy'),'pandas':version('pandas'),'scipy':version('scipy'),
        'seed':args.seed,'device':args.device,'folds':5,
        'fold_order':'author_original_train_order_no_shuffle','members':3,'max_epochs':600,'patience':60,
        'tabpfn_parameters':repr(parameters['tabpfn']),'multitask_parameters':repr(parameters['multitask']),
        'weight_settings':repr(asdict(args.weight_settings)),
        'weight_source_sha256':sha(PROJECT/'scripts/debias_weights.py'),
        'network_source_sha256':sha(PROJECT/'scripts/multitask_cv.py'),
        'runner_source_sha256':sha(Path(__file__)),
        'input_features':x.shape[1],'targets':y.shape[1],'features_removed':0,
        'weight_learning_uses_targets':False,'weight_learning_uses_style':False,
        'causal_effect_identified':False,'certified_graph_adjustment':False,
        'debias_definition':'input_dependency_reweighting_inspired_by_DWR_and_StableNet_not_full_reproduction',
        'tabpfn_weight_interface':'all_original_rows_plus_systematic_weighted_repeats',
        'strength_selection':'mean_5fold_R2_training_only_not_nested_CV',
        'test_previously_inspected':True,
    }


def guard(output,expected):
    output.mkdir(parents=True,exist_ok=True)
    path=output/'run.csv'
    if path.exists():
        previous=pd.read_csv(path).set_index('setting')['value']
        for key,value in expected.items():
            if str(previous.get(key))!=str(value):
                raise ValueError(f'Run settings changed: {key}; choose a new output directory.')
    write_status(output,expected,'running')


def write_status(output,expected,status):
    pd.Series({**expected,'status':status},name='value').rename_axis('setting').to_csv(
        output/'run.csv',encoding='utf-8-sig')


def reference_prediction(family,signature,metadata,folds):
    directory=PROJECT/'results/tuned_seed_0'/family
    run=pd.read_csv(directory/'run.csv').set_index('setting')['value']
    if run['dataset_sha256']!=signature or run['status']!='completed':
        raise ValueError('Reference data or search status differs.')
    assignments=metadata.copy()
    assignments['fold']=0
    for fold,(_,valid) in enumerate(folds,1):
        assignments.loc[valid,'fold']=fold
    pd.testing.assert_frame_equal(assignments,pd.read_csv(directory/'fold_assignments.csv'))
    trial=int(pd.read_csv(directory/'best_parameters.csv').set_index('parameter').loc['trial','value'])
    values=np.load(directory/'cv_predictions.npy',mmap_mode='r')[trial]
    if values.shape!=(len(metadata),50) or not np.isfinite(values).all():
        raise ValueError('Invalid reference OOF predictions.')
    return values


def nn_predict(params,x,y,evaluation,seed,device,factory,strength):
    predictions,records=[],[]
    for member in range(3):
        model,xs,ys,info=fit_member(
            np.asarray(x),np.asarray(y),seed=seed+member,device=device,
            sample_weight_factory=lambda values:factory(values,strength),
            max_epochs=600,patience=60,**params)
        with torch.no_grad():
            values=torch.as_tensor(xs.transform(np.asarray(evaluation)),device=device)
            predictions.append(ys.inverse_transform(model(values).cpu().numpy()))
        records.append({'member':member+1,'seed':seed+member,**info})
        del model,values
    return np.mean(predictions,axis=0),records


def predict_config(config,parameters,x,y,evaluation,metadata,args,factory,output,seed):
    output.mkdir(parents=True,exist_ok=True)
    if config['family']=='tabpfn':
        weights=factory(x,config['strength']) if config['strength'] else np.ones(len(x))
        rows,counts=retained_context(weights)
        if x.shape[1]!=231 or not np.all(counts>=1):
            raise ValueError('The context must retain every original training row and all inputs.')
        pd.DataFrame({
            'beer':metadata.beer.to_numpy(),'requested_weight':weights,
            'context_multiplicity':counts,'context_mean_normalized_weight':counts/counts.mean(),
        }).to_csv(output/'context_weights.csv',index=False,encoding='utf-8-sig')
        result=tabpfn_predict(parameters['tabpfn'],x.iloc[rows],y.iloc[rows],evaluation,
                              model_path=args.model_path,device=args.device,seed=args.seed)
    else:
        result,records=nn_predict(parameters['multitask'],x,y,evaluation,seed,args.device,factory,config['strength'])
        pd.DataFrame(records).to_csv(output/'training.csv',index=False,encoding='utf-8-sig')
    if result.shape!=(len(evaluation),y.shape[1]) or not np.isfinite(result).all():
        raise ValueError('Invalid prediction array.')
    return result


def freeze_strengths(output,table,expected):
    chosen=[]
    for family in ['tabpfn','multitask']:
        candidates=table[(table.family==family)&(table.strength>0)]
        row=candidates.loc[candidates.mean_cv_r2.idxmax()]
        chosen.append({'family':family,'method':row.method,'strength':row.strength,
                       'mean_cv_r2':row.mean_cv_r2,'dataset_sha256':expected['dataset_sha256'],
                       'weight_source_sha256':expected['weight_source_sha256']})
    frame=pd.DataFrame(chosen)
    path=output/'frozen_selection.csv'
    if path.exists():
        pd.testing.assert_frame_equal(pd.read_csv(path),frame,check_dtype=False,atol=1e-12,rtol=0)
    else:
        frame.to_csv(path,index=False,encoding='utf-8-sig')
    return frame


def run(args):
    torch.set_num_threads(4)
    x,y,metadata,folds=load_protocol(args.data_dir,args.seed)
    parameters={family:read_parameters(PROJECT/'results/tuned_seed_0'/family/'best_parameters.csv')
                for family in ['tabpfn','multitask']}
    expected=settings(args,x,y,metadata,parameters)
    guard(args.output_dir,expected)
    predictions,done=make_store(args.output_dir,CONFIGS,(len(CONFIGS),len(x),y.shape[1]))
    signature=expected['dataset_sha256']
    reference={family:reference_prediction(family,signature,metadata,folds) for family in ['tabpfn','multitask']}
    baseline=np.empty(y.shape)
    assignments=metadata.copy()
    assignments['fold']=0
    metrics=[]
    try:
        for fold,(train,valid) in enumerate(folds):
            tick=perf_counter()
            factory=WeightFactory(args.weight_settings,args.device)
            xtrain,ytrain,meta=x.iloc[train],y.iloc[train],metadata.iloc[train]
            baseline[valid]=ytrain.mean().to_numpy()
            assignments.loc[valid,'fold']=fold+1
            for trial,config in enumerate(CONFIGS):
                invalid=done[trial,fold]&~np.isfinite(predictions[trial,valid]).all(axis=0)
                done[trial,fold,invalid]=False
                if not done[trial,fold].all():
                    if config['method'].endswith('_original'):
                        values=reference[config['family']][valid]
                    else:
                        directory=args.output_dir/f'fold_{fold+1}'/config['method']
                        values=predict_config(config,parameters,xtrain,ytrain,x.iloc[valid],meta,args,factory,
                                              directory,args.seed+(fold+1)*1000 if config['family']=='multitask' else args.seed)
                    predictions[trial,valid]=values
                    predictions.flush()
                    done[trial,fold]=True
                    done.flush()
                metric=macro_scores(y.iloc[valid].to_numpy(),predictions[trial,valid])
                metrics.append({'method':config['method'],'family':config['family'],'strength':config['strength'],
                                'fold':fold+1,**metric})
            factory.export(args.output_dir/f'fold_{fold+1}'/'learned_weights',xtrain,meta)
            pd.DataFrame(metrics).to_csv(args.output_dir/'fold_metrics.csv',index=False,encoding='utf-8-sig')
            print(f'Fold {fold+1}/5 completed ({perf_counter()-tick:.1f}s).',flush=True)
        if not done.all() or not np.isfinite(predictions).all():
            raise ValueError('Search incomplete.')
        assignments.to_csv(args.output_dir/'fold_assignments.csv',index=False,encoding='utf-8-sig')
        comparison=pd.DataFrame(metrics).groupby(['method','family','strength'],sort=False).agg(
            mean_cv_r2=('r2','mean'),std_cv_r2=('r2','std'),mean_cv_mae=('mae','mean'),mean_cv_rmse=('rmse','mean')).reset_index()
        comparison.to_csv(args.output_dir/'cv_comparison.csv',index=False,encoding='utf-8-sig')
        for trial,config in enumerate(CONFIGS):
            export_predictions(args.output_dir/config['method'],y,predictions[trial],assignments,baseline,folds)
        frozen=freeze_strengths(args.output_dir,comparison,expected)
        print(comparison.round(5).to_string(index=False),flush=True)
        if args.stage=='cv':
            write_status(args.output_dir,expected,'cv_completed')
            return
        # The weights and their strengths are frozen before any holdout outcomes are loaded.
        xt,yt,mt=load_split(args.data_dir,'test')
        xt,yt=xt.loc[:,x.columns],yt.loc[:,y.columns]
        if set(metadata.beer)&set(mt.beer):
            raise ValueError('Training and holdout samples overlap.')
        names=['tabpfn_original','tabpfn_context_uniform']+frozen.method.tolist()+['multitask_original']
        summaries=[]
        factory=WeightFactory(args.weight_settings,args.device)
        for method in names:
            config=next(config for config in CONFIGS if config['method']==method)
            output=args.output_dir/method/'test'
            if method.endswith('_original'):
                old=PROJECT/'results/tuned_seed_0'/config['family']/'test/test_predictions.csv'
                frame=pd.read_csv(old)
                predicted=frame.pivot(index='beer',columns='target',values='prediction').loc[mt.beer,yt.columns].to_numpy()
                original=frame.pivot(index='beer',columns='target',values='actual').loc[mt.beer,yt.columns].to_numpy()
                np.testing.assert_allclose(original,yt.to_numpy(),rtol=0,atol=1e-14)
            else:
                predicted=predict_config(config,parameters,x,y,xt,metadata,args,factory,output,args.seed)
            export_predictions(output,yt,predicted,mt,np.broadcast_to(y.mean().to_numpy(),yt.shape))
            score=macro_scores(yt.to_numpy(),predicted)
            row=comparison.set_index('method').loc[method]
            summaries.append({'method':method,'strength':config['strength'],'mean_cv_r2':row.mean_cv_r2,
                              'n_train':len(x),'n_test':len(xt),'input_features':x.shape[1],**score})
            pd.Series({'status':'completed','dataset_sha256':signature,'test_previously_inspected':True},
                      name='value').rename_axis('setting').to_csv(output/'run.csv',encoding='utf-8-sig')
            print(f'Test {method}: R2={score["r2"]:.5f}',flush=True)
        factory.export(args.output_dir/'full_training_weights',x,metadata)
        pd.DataFrame(summaries).to_csv(args.output_dir/'comparison.csv',index=False,encoding='utf-8-sig')
        write_status(args.output_dir,expected,'completed')
    except BaseException:
        write_status(args.output_dir,expected,'interrupted')
        raise


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--data-dir',type=Path,default=Path('data/splits/seed_0'))
    parser.add_argument('--output-dir',type=Path,default=Path('results/debias_reweight_seed_0'))
    parser.add_argument('--model-path',type=Path,default=Path('../pretrained/Prior-Labstabpfn_3_5/tabpfn-v3.5-20260909.safetensors'))
    parser.add_argument('--stage',choices=['cv','all'],default='all')
    parser.add_argument('--seed',type=int,default=0)
    parser.add_argument('--device',default='cuda')
    parser.add_argument('--weight-steps',type=int,default=250)
    args=parser.parse_args()
    args.weight_settings=WeightSettings(steps=args.weight_steps,seed=args.seed)
    args.data_dir,args.output_dir,args.model_path=map(project_path,[args.data_dir,args.output_dir,args.model_path])
    run(args)


if __name__=='__main__':
    main()
