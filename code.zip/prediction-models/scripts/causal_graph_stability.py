from __future__ import annotations

import argparse
import hashlib
from importlib.metadata import version
from pathlib import Path
from time import perf_counter

import networkx as nx
import numpy as np
import pandas as pd

from causal_structure import ancestral_consistency, build_joint
from run_rfci import search_graph
from tabpfn_cv import project_path
from tetrad_runtime import start_tetrad
from tuning_protocol import data_signature, load_protocol


def ancestry_checks(matrix):
    return ancestral_consistency(matrix)

def run(output, repetitions=32, seed=0):
    jar=start_tetrad()
    x,y,metadata,_=load_protocol(project_path(Path('data/splits/seed_0')))
    joint=build_joint(x,y)
    names=list(joint.columns)
    settings={'dataset_sha256':data_signature(x,y,metadata),'resamples':repetitions,'seed':seed,
              'fraction':.8,'sampling':'without_replacement','nodes':len(names),'alpha':.01,
              'algorithm':'Tetrad_RFCI','temporal_prior':True,'predictive_inputs_removed':0,
              'jar_sha256':hashlib.sha256(jar.read_bytes()).hexdigest(),'py_tetrad':version('py-tetrad')}
    directory=output/'stability'
    directory.mkdir(parents=True,exist_ok=True)
    run_path=directory/'run.csv'
    if run_path.exists():
        previous=pd.read_csv(run_path).set_index('setting')['value']
        for key,value in settings.items():
            if str(previous.get(key))!=str(value):
                raise ValueError(f'Stability settings changed: {key}')
    pd.Series({**settings,'status':'running'},name='value').rename_axis('setting').to_csv(run_path,encoding='utf-8-sig')
    rng=np.random.default_rng(seed)
    matrices,validity=[],[]
    started=perf_counter()
    for repetition in range(repetitions):
        rows=np.sort(rng.choice(len(joint),size=int(.8*len(joint)),replace=False))
        path=directory/f'resample_{repetition+1:03d}.npz'
        if path.exists():
            with np.load(path,allow_pickle=False) as saved:
                np.testing.assert_array_equal(saved['beers'],metadata.iloc[rows].beer.to_numpy())
                np.testing.assert_array_equal(saved['names'],np.asarray(names))
                matrix=saved['matrix']
        else:
            graph,_=search_graph(joint.iloc[rows],.01,True)
            lookup={node.get_name():i for i,node in enumerate(graph.get_nodes())}
            if set(lookup)!=set(names):
                raise ValueError('Resampled graph lost nodes.')
            order=[lookup[name] for name in names]
            matrix=graph.graph[np.ix_(order,order)].astype(np.int8)
            np.savez_compressed(path,matrix=matrix,beers=metadata.iloc[rows].beer.to_numpy(),names=np.asarray(names))
        if matrix.shape != (len(names),len(names)):
            raise ValueError('Invalid graph dimensions.')
        matrices.append(matrix)
        validity.append(ancestry_checks(matrix))
    stack=np.stack(matrices)
    base=pd.read_csv(output/'all_relations.csv')
    no_prior=pd.read_csv(output/'no_temporal/pag_endpoints.csv',index_col=0).reindex(index=names,columns=names).to_numpy()
    index={name:i for i,name in enumerate(names)}
    records=[]
    for row in base.to_dict('records'):
        i,j=index[row['node_a']],index[row['node_b']]
        aa,bb=stack[:,i,j],stack[:,j,i]
        present=(aa!=0)&(bb!=0)
        exact=(aa==row['endpoint_a'])&(bb==row['endpoint_b'])
        records.append({
            **row,'adjacency_frequency':present.mean(),'same_endpoints_frequency':exact.mean(),
            'same_endpoints_in_basic_consistent_graphs_frequency':(exact & np.asarray(validity)).mean(),
            'latent_compatible_frequency':((aa==1)&(bb==1)).mean(),
            'circle_endpoint_frequency':((aa==2)|(bb==2)).mean(),
            'without_prior_endpoint_a':int(no_prior[i,j]),'without_prior_endpoint_b':int(no_prior[j,i]),
            'same_endpoints_without_prior':bool(no_prior[i,j]==row['endpoint_a'] and no_prior[j,i]==row['endpoint_b']),
            'resamples':repetitions,'frequency_is_not_causal_probability':True,
        })
    report=pd.DataFrame(records)
    report.to_csv(output/'relation_stability.csv',index=False,encoding='utf-8-sig')
    report.loc[report.role_a!=report.role_b].to_csv(output/'chemical_sensory_stability.csv',index=False,encoding='utf-8-sig')
    pd.Series({**settings,'status':'completed','basic_ancestral_consistent_resamples':sum(validity),
               'seconds':perf_counter()-started},name='value').rename_axis('setting').to_csv(run_path,encoding='utf-8-sig')
    print(f'Completed {repetitions} full-node resamples; basic ancestral checks passed {sum(validity)}/{repetitions}.',flush=True)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output-dir',type=Path,default=Path('results/causal_rfci_seed_0'))
    parser.add_argument('--resamples',type=int,default=32)
    parser.add_argument('--seed',type=int,default=0)
    args=parser.parse_args()
    run(project_path(args.output_dir),args.resamples,args.seed)


if __name__=='__main__':
    main()
