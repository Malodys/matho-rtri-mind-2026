from __future__ import annotations

import argparse
from dataclasses import asdict
import hashlib
from importlib.metadata import version
from pathlib import Path
import platform
from time import perf_counter

import numpy as np
import pandas as pd

from causal_screen import AGGREGATES, Settings, analyse, export_analysis, export_input_network, feature_labels, selection_frame, summarize_evidence
from finalize_tuning import read_parameters
from tabpfn_cv import PROJECT, project_path
from tuning_protocol import data_signature, export_predictions, load_protocol, macro_scores, make_store

METHODS = ('all', 'primitive', 'marginal_matched', 'conditional', 'marginal_style_matched', 'style_conditional')


def file_hash(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def frozen_settings(args, features, targets, metadata, params):
    return {
        **asdict(args.settings), 'dataset_sha256': data_signature(features, targets, metadata),
        'checkpoint_sha256': file_hash(args.model_path), 'parameters': repr(params),
        'python': platform.python_version(), 'numpy': version('numpy'), 'pandas': version('pandas'),
        'scipy': version('scipy'), 'tabpfn': version('tabpfn'), 'torch': version('torch'),
        'device': args.device, 'fold_order': 'author_original_train_order_no_shuffle',
        'test_data_used': False, 'other_sensory_targets_used_as_predictors': False,
        'method_version': 1,
    }


def guard_run(output, expected):
    output.mkdir(parents=True, exist_ok=True)
    path = output / 'run.csv'
    if path.exists():
        previous = pd.read_csv(path).set_index('setting')['value']
        for key, value in expected.items():
            if str(previous.get(key)) != str(value):
                raise ValueError(f'Run setting changed: {key}; choose a new output directory.')
    pd.Series({**expected, 'status': 'running'}, name='value').rename_axis('setting').to_csv(
        path, encoding='utf-8-sig')


def analyse_cached(output, features, targets, metadata, settings, labels):
    fingerprint = data_signature(features, targets, metadata)
    audit_path = output / 'analysis_run.csv'
    if audit_path.exists():
        audit = pd.read_csv(audit_path).set_index('setting')['value']
        if audit.get('dataset_sha256') != fingerprint:
            raise ValueError('Selection rows changed; choose a new output directory.')
        for key, value in asdict(settings).items():
            if str(audit.get(key)) != str(value):
                raise ValueError(f'Selection setting changed: {key}')
        frame = pd.read_csv(output / 'selected_features.csv').sort_values(['target', 'method', 'rank'])
        selections = {target: {method: group['feature'].tolist()
                              for method, group in block.groupby('method', sort=False)}
                      for target, block in frame.groupby('target', sort=False)}
        return selections
    report, selections, audit = analyse(features, targets, metadata['tasting_category_fine'], settings)
    audit['dataset_sha256'] = fingerprint
    export_analysis(output, report, selections, audit, labels)
    metadata.to_csv(output / 'training_beers.csv', index=False, encoding='utf-8-sig')
    return selections


def predict_selected(model, x_train, y_train, x_valid, selections, method, columns, batch_size=4):
    grouped = {}
    for position, column in enumerate(columns):
        names = selections[y_train.columns[column]][method]
        grouped.setdefault(len(names), []).append((position, column, names))
    predictions = [None] * len(columns)
    for group in grouped.values():
        for start in range(0, len(group), batch_size):
            batch = group[start:start + batch_size]
            result = model.predict_batched(
                [x_train[names] for _, _, names in batch],
                [y_train.iloc[:, column] for _, column, _ in batch],
                [x_valid[names] for _, _, names in batch],
            )
            if len(result) != len(batch):
                raise ValueError('Incomplete prediction batch.')
            for (position, _, _), values in zip(batch, result):
                values = np.asarray(values).reshape(-1)
                if values.shape != (len(x_valid),) or not np.isfinite(values).all():
                    raise ValueError('Invalid selected-feature predictions.')
                predictions[position] = values
    return np.column_stack(predictions)


def run(args):
    import torch
    from tabpfn import TabPFNRegressor

    torch.set_num_threads(4)
    features, targets, metadata, folds = load_protocol(args.data_dir, args.seed)
    params = read_parameters(PROJECT / 'results/tuned_seed_0/tabpfn/best_parameters.csv')
    expected = frozen_settings(args, features, targets, metadata, params)
    guard_run(args.output_dir, expected)
    labels = feature_labels(PROJECT)
    stamp = perf_counter()
    try:
        report_dir = args.output_dir / 'training_analysis'
        analyse_cached(report_dir, features, targets, metadata, args.settings, labels)
        export_input_network(report_dir, features, metadata['tasting_category_fine'], labels)
        print(f'Training-only variable analysis saved ({perf_counter()-stamp:.1f}s).', flush=True)
        if args.stage == 'analysis':
            status = 'analysis_completed'
        else:
            configs = [{'method': method} for method in METHODS]
            predictions, done = make_store(args.output_dir, configs, (len(METHODS), len(features), targets.shape[1]))
            model = TabPFNRegressor(
                model_path=args.model_path, device=args.device, random_state=args.seed,
                show_progress_bar=False, **params)
            fold_rows, all_selection_rows = [], []
            baseline = np.empty(targets.shape)
            assignments = metadata.copy()
            assignments['fold'] = 0
            for fold, (train, valid) in enumerate(folds):
                tick = perf_counter()
                x_train, y_train = features.iloc[train], targets.iloc[train]
                train_meta = metadata.iloc[train]
                subset_settings = Settings(**{**asdict(args.settings), 'seed': args.seed + fold + 1})
                selections = analyse_cached(args.output_dir / f'fold_{fold+1}', x_train, y_train,
                                            train_meta, subset_settings, labels)
                selection_rows = selection_frame(selections, fold + 1)
                all_selection_rows.append(selection_rows)
                baseline[valid] = y_train.mean().to_numpy()
                assignments.loc[valid, 'fold'] = fold + 1
                for i, method in enumerate(METHODS):
                    stale = done[i, fold] & ~np.isfinite(predictions[i, valid]).all(axis=0)
                    done[i, fold, stale] = False
                    pending = np.flatnonzero(~done[i, fold]).tolist()
                    # Reuse the previously verified all-feature fold predictions only after exact identity checks.
                    if method == 'all' and pending:
                        old = PROJECT / 'results/tuned_seed_0/tabpfn'
                        previous = pd.read_csv(old / 'run.csv').set_index('setting')['value']
                        for key in ['dataset_sha256', 'checkpoint_sha256', 'python', 'tabpfn', 'torch', 'device']:
                            if str(previous[key]) != str(expected[key]):
                                raise ValueError(f'All-feature baseline identity differs: {key}')
                        if previous['status'] != 'completed':
                            raise ValueError('All-feature baseline is incomplete.')
                        trial = int(pd.read_csv(old / 'best_parameters.csv').set_index('parameter').loc['trial', 'value'])
                        old_values = np.load(old / 'cv_predictions.npy', mmap_mode='r')[trial, valid]
                        if not np.isfinite(old_values).all():
                            raise ValueError('Invalid saved baseline.')
                        predictions[i, valid] = old_values
                        predictions.flush()
                        done[i, fold] = True
                        done.flush()
                        pending = []
                    for start in range(0, len(pending), args.batch_size):
                        columns = pending[start:start + args.batch_size]
                        values = predict_selected(model, x_train, y_train, features.iloc[valid],
                                                  selections, method, columns, args.batch_size)
                        for j, column in enumerate(columns):
                            predictions[i, valid, column] = values[:, j]
                        predictions.flush()
                        done[i, fold, columns] = True
                        done.flush()
                    scores = macro_scores(targets.iloc[valid].to_numpy(), predictions[i, valid])
                    fold_rows.append({'method': method, 'fold': fold + 1,
                                      'mean_features': np.mean([len(selections[t][method]) for t in targets]), **scores})
                pd.DataFrame(fold_rows).to_csv(args.output_dir / 'fold_metrics.csv', index=False, encoding='utf-8-sig')
                pd.concat(all_selection_rows).to_csv(args.output_dir / 'fold_selections.csv', index=False, encoding='utf-8-sig')
                print(f'Fold {fold+1}/5 completed ({perf_counter()-tick:.1f}s).', flush=True)
            if not done.all() or not np.isfinite(predictions).all():
                raise ValueError('Incomplete five-fold comparison.')
            assignments.to_csv(args.output_dir / 'fold_assignments.csv', index=False, encoding='utf-8-sig')
            summary = pd.DataFrame(fold_rows).groupby('method', sort=False).agg(
                mean_cv_r2=('r2', 'mean'), std_cv_r2=('r2', 'std'), mean_cv_mae=('mae', 'mean'),
                mean_cv_rmse=('rmse', 'mean'), mean_features=('mean_features', 'mean'))
            for i, method in enumerate(METHODS):
                export_predictions(args.output_dir / method, targets, predictions[i], assignments, baseline, folds)
                summary.loc[method, 'pooled_oof_r2'] = macro_scores(targets.to_numpy(), predictions[i])['r2']
            summary.to_csv(args.output_dir / 'comparison.csv', encoding='utf-8-sig')
            summarize_evidence(args.output_dir)
            print(summary.round(5).to_string(), flush=True)
            status = 'completed'
        pd.Series({**expected, 'status': status, 'seconds': perf_counter()-stamp},
                  name='value').rename_axis('setting').to_csv(args.output_dir / 'run.csv', encoding='utf-8-sig')
    except BaseException:
        pd.Series({**expected, 'status': 'interrupted'}, name='value').rename_axis('setting').to_csv(
            args.output_dir / 'run.csv', encoding='utf-8-sig')
        raise


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data-dir', type=Path, default=Path('data/splits/seed_0'))
    parser.add_argument('--output-dir', type=Path, default=Path('results/causal_screen_seed_0'))
    parser.add_argument('--model-path', type=Path, default=Path('../pretrained/Prior-Labstabpfn_3_5/tabpfn-v3.5-20260909.safetensors'))
    parser.add_argument('--stage', choices=['analysis', 'all'], default='all')
    parser.add_argument('--bootstraps', type=int, default=64)
    parser.add_argument('--max-blanket', type=int, default=10)
    parser.add_argument('--alpha', type=float, default=.01)
    parser.add_argument('--stability', type=float, default=.6)
    parser.add_argument('--seed', type=int, default=0)
    parser.add_argument('--device', default='cuda')
    parser.add_argument('--batch-size', type=int, default=4)
    args = parser.parse_args()
    args.settings = Settings(bootstraps=args.bootstraps, max_blanket=args.max_blanket,
                             alpha=args.alpha, stability=args.stability, seed=args.seed)
    args.data_dir, args.output_dir, args.model_path = map(project_path, [args.data_dir, args.output_dir, args.model_path])
    run(args)


if __name__ == '__main__':
    main()
