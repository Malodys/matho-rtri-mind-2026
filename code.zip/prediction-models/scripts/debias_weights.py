from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import numpy as np
from scipy.stats import norm, rankdata
import torch


@dataclass(frozen=True)
class WeightSettings:
    steps: int = 250
    learning_rate: float = .03
    variance_penalty: float = .1
    ess_fraction: float = .8
    max_weight: float = 5.
    seed: int = 0


def effective_sample_size(weights):
    weights=np.asarray(weights,dtype=float)
    return float(weights.sum()**2/np.square(weights).sum())


def feature_map(values, seed=0):
    values=np.asarray(values,dtype=float)
    if values.ndim!=2 or np.isinf(values).any():
        raise ValueError('Invalid weighting inputs.')
    ranks=np.zeros_like(values)
    for j in range(values.shape[1]):
        observed=np.isfinite(values[:,j])
        count=int(observed.sum())
        if count:
            r=rankdata(values[observed,j],method='average')
            ranks[observed,j]=norm.ppf((r-.5)/count)
    frequency=np.random.default_rng(seed).normal(size=values.shape[1])
    transformed=np.stack((ranks,np.sin(ranks*frequency),np.cos(ranks*frequency)),axis=2)
    transformed -= transformed.mean(axis=0,keepdims=True)
    scale=transformed.std(axis=0,keepdims=True)
    transformed /= np.where(scale>1e-8,scale,1.)
    return transformed.astype(np.float32)


def covariance_balance(mapped,weights):
    shape=mapped.shape
    flat=mapped.reshape(shape[0],-1)
    weights=weights/weights.sum()
    mean=(flat*weights[:,None]).sum(dim=0)
    covariance=flat.T @ (flat*weights[:,None])-mean[:,None]*mean[None,:]
    within=covariance.reshape(shape[1],shape[2],shape[1],shape[2]).diagonal(dim1=0,dim2=2)
    total=covariance.square().sum()-within.square().sum()
    denominator=shape[1]*(shape[1]-1)*shape[2]**2
    return total/max(denominator,1)


def blend_weights(base,strength):
    if not 0<=strength<=1:
        raise ValueError('Weight strength must be between zero and one.')
    return 1+strength*(np.asarray(base,dtype=float)-1)


def learn_weights(features,settings=WeightSettings(),device='cpu'):
    features=np.asarray(features,dtype=float)
    if len(features)<20 or features.shape[1]<2:
        raise ValueError('Weight estimation needs at least 20 rows and two inputs.')
    if settings.steps < 1 or settings.learning_rate <= 0 or settings.variance_penalty < 0:
        raise ValueError('Invalid weighting optimization settings.')
    if not 0<settings.ess_fraction<=1 or settings.max_weight<1:
        raise ValueError('Invalid effective-sample-size constraint.')
    original=features.copy()
    mapped=torch.as_tensor(feature_map(features,settings.seed),device=device)
    n=len(features)
    uniform=torch.ones(n,device=device)
    with torch.no_grad():
        initial=float(covariance_balance(mapped,uniform).cpu())
    if initial<1e-10:
        return np.ones(n),{'balance_before':initial,'balance_after':initial,'ess':float(n),'fallback':'no_dependence_signal'}
    logits=torch.zeros(n,device=device,requires_grad=True)
    optimizer=torch.optim.Adam([logits],lr=settings.learning_rate)
    best,best_value=np.ones(n),1.
    for _ in range(settings.steps):
        optimizer.zero_grad(set_to_none=True)
        weights=torch.softmax(logits,dim=0)*n
        balance=covariance_balance(mapped,weights)
        objective=balance/initial+settings.variance_penalty*(weights-1).square().mean()
        if not torch.isfinite(objective):
            raise ValueError('Non-finite weighting objective.')
        value=float(objective.detach().cpu())
        if value<best_value:
            best_value=value
            best=weights.detach().cpu().numpy().astype(float)
        objective.backward()
        optimizer.step()
    best/=best.mean()
    upper=1.
    if best.max()>settings.max_weight:
        upper=min(upper,(settings.max_weight-1)/(best.max()-1))
    if best.min()<.1:
        upper=min(upper,.9/(1-best.min()))
    lo,hi=0.,upper
    for _ in range(50):
        mid=(lo+hi)/2
        if effective_sample_size(blend_weights(best,mid))>=settings.ess_fraction*n:
            lo=mid
        else:
            hi=mid
    final=blend_weights(best,lo)
    with torch.no_grad():
        after=float(covariance_balance(mapped,torch.as_tensor(final,dtype=mapped.dtype,device=device)).cpu())
    fallback=''
    if after>initial:
        final=np.ones(n)
        after=initial
        fallback='no_balance_improvement'
    np.testing.assert_equal(features,original)
    return final,{
        'balance_before':initial,'balance_after':after,'balance_ratio':after/initial,
        'ess':effective_sample_size(final),'min_weight':float(final.min()),'max_weight':float(final.max()),
        'n_samples':n,'n_features':features.shape[1],'fallback':fallback,
    }


def retained_context(weights,offset=.5):
    weights=np.asarray(weights,dtype=float)
    if weights.ndim!=1 or not np.isfinite(weights).all() or np.any(weights<=0):
        raise ValueError('Context weights must be positive and finite.')
    if not 0<offset<1:
        raise ValueError('Offset must be inside the unit interval.')
    n=len(weights)
    cumulative=np.cumsum(weights/weights.sum())
    cumulative[-1]=1.
    extra=np.searchsorted(cumulative,(np.arange(n)+offset)/n,side='right')
    rows=np.concatenate((np.arange(n),extra))
    return rows,np.bincount(rows,minlength=n)


class WeightFactory:
    def __init__(self,settings,device='cpu'):
        self.settings,self.device=settings,device
        self.cache={}
        self.calls=[]

    def __call__(self,features,strength=1.):
        values=np.asarray(features,dtype=np.float64)
        key=hashlib.sha256(np.ascontiguousarray(values).tobytes()).hexdigest()
        if key not in self.cache:
            weights,diagnostics=learn_weights(values,self.settings,self.device)
            self.cache[key]=(weights,diagnostics,values.copy())
        base,diagnostics,_=self.cache[key]
        weights=blend_weights(base,strength)
        self.calls.append({
            'input_sha256':key,'n_samples':len(values),'n_features':values.shape[1],
            'strength':strength,'ess_after_strength':effective_sample_size(weights),**diagnostics,
        })
        return weights

    def export(self,path,reference,metadata):
        import pandas as pd
        path.mkdir(parents=True,exist_ok=True)
        row_ids={}
        for position,row in enumerate(np.asarray(reference,dtype=np.float64)):
            digest=hashlib.sha256(row.tobytes()).hexdigest()
            row_ids.setdefault(digest,[]).append(metadata.iloc[position]['beer'])
        for key,(weights,diagnostics,values) in self.cache.items():
            beers=['|'.join(map(str,row_ids[hashlib.sha256(row.tobytes()).hexdigest()])) for row in values]
            pd.DataFrame({'beer':beers,'weight':weights}).to_csv(path/f'weights_{key[:16]}.csv',index=False,encoding='utf-8-sig')
        pd.DataFrame(self.calls).to_csv(path/'diagnostics.csv',index=False,encoding='utf-8-sig')
