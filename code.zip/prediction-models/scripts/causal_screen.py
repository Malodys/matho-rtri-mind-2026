from __future__ import annotations

from dataclasses import asdict, dataclass
import numpy as np
import pandas as pd
from scipy.stats import norm, rankdata

AGGREGATES = ('esters_sum', 'aroma_hops_sum', 'acids_sum', 'sulfur_sum')


@dataclass(frozen=True)
class Settings:
    bootstraps: int = 64
    fraction: float = .8
    alpha: float = .01
    max_blanket: int = 10
    stability: float = .6
    seed: int = 0

    def validate(self):
        if self.bootstraps < 1 or not 0 < self.fraction <= 1:
            raise ValueError('Invalid resampling settings.')
        if not 0 < self.alpha < 1 or self.max_blanket < 1 or not 0 < self.stability <= 1:
            raise ValueError('Invalid selection settings.')


def gaussian_ranks(values):
    values = np.asarray(values, dtype=float)
    if values.ndim != 2 or np.isinf(values).any():
        raise ValueError('Expected a finite-or-missing matrix.')
    out = np.zeros_like(values)
    for column in range(values.shape[1]):
        observed = np.isfinite(values[:, column])
        count = observed.sum()
        if count:
            ranks = rankdata(values[observed, column], method='average')
            out[observed, column] = norm.ppf((ranks - .5) / count)
    return out


def dependence_matrix(x, y, styles=None):
    values = gaussian_ranks(np.column_stack((x, y)))
    n = len(values)
    if styles is None:
        controls = np.ones((n, 1))
    else:
        controls = pd.get_dummies(pd.Series(styles), dtype=float).to_numpy()
    q, r = np.linalg.qr(controls, mode='reduced')
    rank = np.linalg.matrix_rank(r)
    # Dummy columns are disjoint; centering by group removes their full column space.
    values -= q[:, :rank] @ (q[:, :rank].T @ values)
    scale = np.sqrt(np.square(values).sum(axis=0))
    nonconstant = scale > 1e-10
    normalized = np.zeros_like(values)
    normalized[:, nonconstant] = values[:, nonconstant] / scale[nonconstant]
    return normalized.T @ normalized, rank


def conditional_scores(correlation, target, conditioning, n, control_rank, p):
    xy = correlation[:p, target].copy()
    vx = np.diag(correlation)[:p].copy()
    vy = correlation[target, target]
    if conditioning:
        s = np.asarray(conditioning, dtype=int)
        css = correlation[np.ix_(s, s)]
        cross = correlation[:p, s]
        inverse = np.linalg.pinv(css, rcond=1e-10)
        xy -= cross @ inverse @ correlation[s, target]
        vx -= np.einsum('ij,ij->i', cross @ inverse, cross)
        vy -= correlation[target, s] @ inverse @ correlation[s, target]
    denominator = np.sqrt(np.maximum(vx, 0) * max(vy, 0))
    valid = denominator > 1e-9
    rho = np.zeros(p)
    rho[valid] = xy[valid] / denominator[valid]
    rho = np.clip(rho, -.999999, .999999)
    dof = n - control_rank - len(conditioning) - 2
    probabilities = np.ones(p)
    if dof > 0:
        probabilities[valid] = 2 * norm.sf(np.abs(np.arctanh(rho[valid])) * np.sqrt(dof))
    return rho, probabilities


def bh_rejections(probabilities, alpha):
    probabilities = np.asarray(probabilities)
    order = np.argsort(probabilities, kind='stable')
    passes = probabilities[order] <= alpha * np.arange(1, len(order) + 1) / len(order)
    if not passes.any():
        return np.zeros(len(order), dtype=bool)
    return probabilities <= probabilities[order[np.flatnonzero(passes)[-1]]]


def local_blanket(correlation, target, p, n, control_rank, settings):
    """Capped IAMB-style search with approximate rank-Gaussian conditional tests."""
    selected = []
    for _ in range(settings.max_blanket):
        rho, probabilities = conditional_scores(correlation, target, selected, n, control_rank, p)
        candidates = np.array([i for i in range(p) if i not in selected], dtype=int)
        if not len(candidates):
            break
        accepted = bh_rejections(probabilities[candidates], settings.alpha)
        if not accepted.any():
            break
        allowed = candidates[accepted]
        selected.append(int(allowed[np.argmax(np.abs(rho[allowed]))]))
    capped = len(selected) == settings.max_blanket
    while selected:
        probabilities = []
        for feature in selected:
            rest = [item for item in selected if item != feature]
            _, values = conditional_scores(correlation, target, rest, n, control_rank, p)
            probabilities.append(values[feature])
        worst = int(np.argmax(probabilities))
        if probabilities[worst] <= settings.alpha:
            break
        selected.pop(worst)
    return selected, capped


def stable_subset(frequency, marginal, settings):
    stable = np.flatnonzero(frequency >= settings.stability)
    ordered = sorted(stable, key=lambda j: (-frequency[j], -abs(marginal[j]), int(j)))
    if ordered:
        return np.asarray(ordered[:settings.max_blanket], dtype=int), False
    # A fallback permits prediction; it never counts as stable causal evidence.
    return np.asarray([int(np.argmax(np.abs(marginal)))]), True


def analyse(features, targets, styles, settings):
    settings.validate()
    if len(features) != len(targets) or len(features) != len(styles):
        raise ValueError('Unaligned analysis rows.')
    eligible = [name for name in features.columns if name not in AGGREGATES]
    x = features[eligible].to_numpy(dtype=float, copy=True)
    y = targets.to_numpy(dtype=float, copy=True)
    if not np.isfinite(y).all() or len(x) < 20:
        raise ValueError('Analysis needs at least 20 rows and observed targets.')
    p, t, n = x.shape[1], y.shape[1], len(x)
    sample_size = int(np.floor(settings.fraction * n))
    if sample_size < 20:
        raise ValueError('Too few resampled rows.')
    rng = np.random.default_rng(settings.seed)
    counts = {mode: np.zeros((p, t), dtype=int) for mode in ['unadjusted', 'style_adjusted']}
    full, capped = {}, {mode: 0 for mode in counts}
    style_values = np.asarray(styles)
    for mode in counts:
        correlation, rank = dependence_matrix(x, y, style_values if mode == 'style_adjusted' else None)
        full[mode] = (correlation, rank)
    for _ in range(settings.bootstraps):
        rows = rng.choice(n, size=sample_size, replace=False)
        for mode in counts:
            groups = style_values[rows] if mode == 'style_adjusted' else None
            correlation, rank = dependence_matrix(x[rows], y[rows], groups)
            for j in range(t):
                chosen, limit = local_blanket(correlation, p + j, p, sample_size, rank, settings)
                counts[mode][chosen, j] += 1
                capped[mode] += int(limit)
    records, selections = [], {}
    for j, target in enumerate(targets.columns):
        marginal = (features[eligible].corrwith(targets[target], method='spearman').fillna(0).to_numpy()
                    if targets[target].nunique() > 1 else np.zeros(p))
        frequencies = {mode: values[:, j] / settings.bootstraps for mode, values in counts.items()}
        chosen = {}
        diagnostics = {}
        for mode in counts:
            ids, fallback = stable_subset(frequencies[mode], marginal, settings)
            chosen[mode] = ids
            correlation, rank = full[mode]
            rho, pv = conditional_scores(correlation, p + j, ids.tolist(), n, rank, p)
            for feature in ids:
                conditioning = [int(item) for item in ids if item != feature]
                rr, pp = conditional_scores(correlation, p + j, conditioning, n, rank, p)
                rho[feature], pv[feature] = rr[feature], pp[feature]
            diagnostics[mode] = (rho, pv, fallback)
        ordinary = np.argsort(-np.abs(marginal), kind='stable')
        selections[target] = {
            'all': list(features.columns), 'primitive': eligible.copy(),
            'conditional': [eligible[i] for i in chosen['unadjusted']],
            'style_conditional': [eligible[i] for i in chosen['style_adjusted']],
            'marginal_matched': [eligible[i] for i in ordinary[:len(chosen['unadjusted'])]],
            'marginal_style_matched': [eligible[i] for i in ordinary[:len(chosen['style_adjusted'])]],
        }
        for i, feature in enumerate(eligible):
            unadj, adj = frequencies['unadjusted'][i], frequencies['style_adjusted'][i]
            evidence = ('stable_both' if min(unadj, adj) >= settings.stability else
                        'style_sensitive' if unadj >= settings.stability else
                        'stable_only_after_style_adjustment' if adj >= settings.stability else 'unstable')
            records.append({
                'target': target, 'feature': feature, 'spearman': marginal[i],
                'frequency': unadj, 'style_adjusted_frequency': adj, 'frequency_change': adj - unadj,
                'partial_rank_gaussian': diagnostics['unadjusted'][0][i],
                'exploratory_p': diagnostics['unadjusted'][1][i],
                'style_partial_rank_gaussian': diagnostics['style_adjusted'][0][i],
                'style_exploratory_p': diagnostics['style_adjusted'][1][i],
                'selected': i in chosen['unadjusted'], 'style_selected': i in chosen['style_adjusted'],
                'selection_fallback': diagnostics['unadjusted'][2],
                'style_selection_fallback': diagnostics['style_adjusted'][2], 'evidence': evidence,
                'n_samples': n, 'resamples': settings.bootstraps,
            })
    report = pd.DataFrame(records)
    audit = {'samples': n, 'input_features': features.shape[1], 'eligible_features': p,
             'targets': t, 'missing_input_cells': int(features.isna().sum().sum()),
             'missing_handling': 'observed_ranks_then_neutral_zero_for_missing_analysis_cells',
             'sampling': 'without_replacement', 'sample_size': sample_size,
             'method': 'capped_IAMB_rank_gaussian_approximate_tests',
             'p_values': 'exploratory_post_selection_not_confirmatory',
             'conditional_test': 'approximate_rank_gaussian_partial_correlation',
             'nonlinear_dependence_comprehensively_tested': False,
             'hidden_confounders_identified': False, 'causal_effects_estimated': False,
             'style_adjustment': 'sensitivity_analysis_not_identified_confounder_adjustment',
             **asdict(settings)}
    audit.update({mode + '_capped_searches': count for mode, count in capped.items()})
    return report, selections, audit


def selection_frame(selections, fold):
    return pd.DataFrame([
        {'fold': fold, 'target': target, 'method': method, 'rank': rank, 'feature': feature}
        for target, methods in selections.items()
        for method, names in methods.items()
        for rank, feature in enumerate(names, 1)
    ])


def feature_labels(project):
    raw = pd.read_csv(project / 'data/raw/1.csv', nrows=0)
    names = [name for name in raw.columns if name not in ['beer', 'beer_id', 'tasting_category_fine']]
    human = pd.read_csv(project / 'data/raw/2.csv', nrows=0).columns[1:]
    if len(human) != len(names):
        raise ValueError('Chemical label count differs.')
    return dict(zip(names, human))


def export_analysis(output, report, selections, audit, labels):
    output.mkdir(parents=True, exist_ok=True)
    report = report.copy()
    report['abs_spearman'] = report['spearman'].abs()
    report['chemical_name'] = report['feature'].map(labels).fillna(report['feature'])
    report.sort_values(['target', 'frequency', 'style_adjusted_frequency'],
                       ascending=[True, False, False]).to_csv(output / 'variable_evidence.csv', index=False, encoding='utf-8-sig')
    selected = report.loc[report['selected'] | report['style_selected']].copy()
    selected.to_csv(output / 'candidate_variables.csv', index=False, encoding='utf-8-sig')
    top = []
    for target, group in report.groupby('target', sort=False):
        ranked = group.sort_values(['frequency', 'style_adjusted_frequency', 'abs_spearman'],
                                  ascending=[False, False, False]).head(3)
        top.extend(ranked.to_dict('records'))
    pd.DataFrame(top).to_csv(output / 'top3_candidates.csv', index=False, encoding='utf-8-sig')
    selection_frame(selections, 0).to_csv(output / 'selected_features.csv', index=False, encoding='utf-8-sig')
    pd.Series(audit, name='value').rename_axis('setting').to_csv(output / 'analysis_run.csv', encoding='utf-8-sig')

def export_input_network(output, features, styles, labels):
    rho = features.corr(method='spearman').to_numpy()
    adjusted, _ = dependence_matrix(features.to_numpy(), np.empty((len(features), 0)), styles)
    present = features.notna().to_numpy(dtype=int)
    counts = present.T @ present
    left, right = np.triu_indices(features.shape[1], 1)
    names = np.asarray(features.columns)
    pd.DataFrame({
        'feature_a': names[left], 'feature_b': names[right],
        'name_a': [labels.get(name, name) for name in names[left]],
        'name_b': [labels.get(name, name) for name in names[right]],
        'spearman': rho[left, right], 'style_adjusted_rank_correlation': adjusted[left, right],
        'pairwise_observed_samples': counts[left, right],
        'involves_derived_aggregate': [a in AGGREGATES or b in AGGREGATES for a,b in zip(names[left],names[right])],
        'edge_type': 'association_not_causal_direction',
    }).to_csv(output / 'input_associations.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame({
        'feature': names, 'chemical_name': [labels.get(name,name) for name in names],
        'role': ['derived_aggregate' if name in AGGREGATES else 'non_aggregate_input' for name in names],
        'eligible_for_local_screen': [name not in AGGREGATES for name in names],
    }).to_csv(output / 'feature_catalog.csv', index=False, encoding='utf-8-sig')


def summarize_evidence(output):
    reports = [pd.read_csv(output / f'fold_{fold}' / 'variable_evidence.csv') for fold in range(1, 6)]
    combined = pd.concat(reports, ignore_index=True)
    full = pd.read_csv(output / 'training_analysis/variable_evidence.csv')
    threshold = float(pd.read_csv(output / 'training_analysis/analysis_run.csv').set_index('setting').loc['stability', 'value'])
    cross = combined.groupby(['target', 'feature', 'chemical_name']).agg(
        mean_frequency=('frequency', 'mean'), min_frequency=('frequency', 'min'),
        mean_style_adjusted_frequency=('style_adjusted_frequency', 'mean'),
        min_style_adjusted_frequency=('style_adjusted_frequency', 'min'),
        stable_folds=('frequency', lambda values: int((values >= threshold).sum())),
        style_stable_folds=('style_adjusted_frequency', lambda values: int((values >= threshold).sum())),
    ).reset_index()
    cross.to_csv(output / 'cross_fold_evidence.csv', index=False, encoding='utf-8-sig')
    candidates = full.loc[(full.frequency >= threshold) | (full.style_adjusted_frequency >= threshold)]
    candidates.merge(cross, on=['target', 'feature', 'chemical_name']).to_csv(
        output / 'candidate_stability.csv', index=False, encoding='utf-8-sig')
    target_summary = full.groupby('target', sort=False).agg(
        stable_candidates=('frequency', lambda values: int((values >= threshold).sum())),
        style_stable_candidates=('style_adjusted_frequency', lambda values: int((values >= threshold).sum())),
        fallback=('selection_fallback', 'first'), style_fallback=('style_selection_fallback', 'first'),
    )
    target_summary.to_csv(output / 'target_summary.csv', encoding='utf-8-sig')
    pd.DataFrame([
        ('stable_both', '两种分析的重抽样入选频率都达到门槛；不等于已证明因果'),
        ('style_sensitive', '普通分析达到门槛、风格调整后未达到；不等于已证明存在混淆'),
        ('stable_only_after_style_adjustment', '仅在风格调整后达到门槛'),
        ('unstable', '两种分析均未达到门槛；不等于没有作用'),
        ('selection_fallback', '未找到稳定候选时，为运行预测保留的普通相关变量；不算稳定证据'),
        ('frequency', '无放回重抽样中的入选比例；不是因果概率'),
        ('exploratory_p', '数据筛选后的近似检验值，不能当作确认性显著性证据'),
    ], columns=['field_or_code', 'meaning']).to_csv(output / 'evidence_legend.csv', index=False, encoding='utf-8-sig')
