from __future__ import annotations

import argparse
import hashlib
from importlib.metadata import version
from pathlib import Path
import subprocess
import sys
from time import perf_counter

import numpy as np
import pandas as pd

from causal_structure import ancestral_consistency, build_joint, export_graph, observed_gaussian_ranks
from causal_screen import feature_labels
from tabpfn_cv import PROJECT, project_path
from tetrad_runtime import start_tetrad
from tuning_protocol import data_signature, load_protocol


def search_graph(joint, alpha, temporal, algorithm='rfci', guarantee=False):
    from pytetrad.tools.TetradSearch import TetradSearch
    transformed = pd.DataFrame(observed_gaussian_ranks(joint), columns=joint.columns)
    model = TetradSearch(transformed)
    model.set_missing_data_policy('testwise')
    model.use_fisher_z(alpha=alpha, singularity_lambda=0.)
    if temporal:
        for name in joint:
            model.knowledge.addToTier(0 if name.startswith('chemical:') else 1, name)
    search = model.run_rfci if algorithm == 'rfci' else model.run_fci
    options = {'guarantee_pag': guarantee} if algorithm == 'fci' else {}
    search(depth=-1, stable_fas=True, max_disc_path_length=-1, complete_rule_set_used=True, **options)
    return model.get_causal_learn(), model


def worker(args):
    jar = start_tetrad()
    x,y,metadata,_ = load_protocol(project_path(args.data_dir))
    joint=build_joint(x,y)
    root=project_path(args.output_dir)
    root.mkdir(parents=True,exist_ok=True)
    settings={
        'algorithm':'Tetrad_'+args.algorithm.upper(),'alpha':args.alpha,'dataset_sha256':data_signature(x,y,metadata),
        'samples':len(x),'chemical_nodes':x.shape[1],'sensory_nodes':y.shape[1],
        'predictive_inputs_removed':0,'depth':-1,'discriminating_path_length':-1,
        'temporal_prior':args.temporal,'temporal_prior_assumption':'sensory_response_not_ancestor_of_composition',
        'missing_data_policy':'testwise','missing_data_imputed':False,
        'conditional_test':'FisherZ_on_observed_Gaussian_ranks',
        'singularity_regularization':0.,'latent_common_causes_allowed':True,
        'py_tetrad':version('py-tetrad'),'jdk4py':version('jdk4py'),'JPype1':version('JPype1'),
        'tetrad_jar_sha256':hashlib.sha256(jar.read_bytes()).hexdigest(),
        'causal_effects_estimated':False,'prediction_model_changed':False,
        'test_samples_used':False,'assumptions_verified':False,
    }
    if args.guarantee_pag: settings['guarantee_pag']=True
    path=root/'run.csv'
    if path.exists():
        previous=pd.read_csv(path).set_index('setting')['value']
        for key,value in settings.items():
            if str(previous.get(key))!=str(value):
                raise ValueError(f'Graph settings changed: {key}')
    def save(status, **extra):
        pd.Series({**settings,'status':status,**extra},name='value').rename_axis('setting').to_csv(path,encoding='utf-8-sig')
    save('running')
    metadata.to_csv(root/'training_beers.csv',index=False,encoding='utf-8-sig')
    tick=perf_counter()
    try:
        graph,model=search_graph(joint,args.alpha,args.temporal,args.algorithm,args.guarantee_pag)
        relations=export_graph(root,graph,graph.get_graph_edges(),x,y,feature_labels(PROJECT))
        # Definite ancestry cycles contradict a causal ancestral-graph interpretation.
        import networkx as nx
        directed=nx.DiGraph()
        directed.add_nodes_from(list(joint.columns))
        for edge in graph.get_graph_edges():
            a,b=edge.get_node1().get_name(),edge.get_node2().get_name()
            ea,eb=edge.get_endpoint1().value,edge.get_endpoint2().value
            if (ea,eb)==(-1,1): directed.add_edge(a,b)
            if (ea,eb)==(1,-1): directed.add_edge(b,a)
        acyclic=nx.is_directed_acyclic_graph(directed)
        conflicts=int(relations.domain_prior_audit.str.startswith('conflicts').sum())
        consistent=ancestral_consistency(graph.graph)
        save('completed_exploratory' if consistent else 'completed_but_ancestral_constraints_failed',
             basic_ancestral_consistent=consistent,valid_adjustment_set_certified=False,seconds=perf_counter()-tick,relations=len(relations),
             definite_ancestry_acyclic=acyclic,temporal_prior_conflicts=conflicts)
        print(f'Completed: {len(joint.columns)} nodes, {len(relations)} relations, {perf_counter()-tick:.1f}s.',flush=True)
    except BaseException as error:
        save('failed_no_completed_graph',details=repr(error),seconds=perf_counter()-tick)
        raise


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--data-dir',type=Path,default=Path('data/splits/seed_0'))
    parser.add_argument('--output-dir',type=Path,default=Path('results/causal_rfci_seed_0'))
    parser.add_argument('--alpha',type=float,default=.01)
    parser.add_argument('--algorithm',choices=['rfci','fci'],default='rfci')
    parser.add_argument('--temporal',action=argparse.BooleanOptionalAction,default=True)
    parser.add_argument('--max-seconds',type=int,default=300)
    parser.add_argument('--guarantee-pag',action='store_true')
    parser.add_argument('--worker',action='store_true')
    args=parser.parse_args()
    if args.worker:
        worker(args)
        return
    output=project_path(args.output_dir)
    output.mkdir(parents=True,exist_ok=True)
    command=[sys.executable,str(Path(__file__).resolve()),'--worker','--data-dir',str(project_path(args.data_dir)),
             '--output-dir',str(output),'--algorithm',args.algorithm,'--alpha',str(args.alpha),'--temporal' if args.temporal else '--no-temporal']
    if args.guarantee_pag: command.append('--guarantee-pag')
    print(f'{args.algorithm.upper()}: full 231+50 nodes, temporal_prior={args.temporal}, alpha={args.alpha}.',flush=True)
    try:
        with (output/'algorithm.log').open('a',encoding='utf-8') as log:
            result=subprocess.run(command,stdout=log,stderr=log,timeout=args.max_seconds)
        if result.returncode:
            raise RuntimeError(f'RFCI failed; see {output / "algorithm.log"}')
        print(pd.read_csv(output/'run.csv').tail(6).to_string(index=False),flush=True)
    except subprocess.TimeoutExpired:
        path=output/'run.csv'
        settings=pd.read_csv(path).set_index('setting')['value'].to_dict() if path.exists() else {}
        settings['status']='time_budget_exhausted_no_completed_graph'
        pd.Series(settings,name='value').rename_axis('setting').to_csv(path,encoding='utf-8-sig')
        raise RuntimeError('RFCI exceeded its wall-time budget; no completed graph is claimed.')


if __name__=='__main__':
    main()
