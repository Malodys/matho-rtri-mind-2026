from __future__ import annotations
import argparse
import hashlib
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from finalize_tuning import read_parameters
from tabpfn_cv import PROJECT, load_split, project_path
from tuning_protocol import load_protocol, macro_scores, export_predictions

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path, default=Path("results/global_median_seed_0"))
    parser.add_argument("--models", nargs="+", default=["gbr", "rf", "tabpfn", "multitask"])
    parser.add_argument("--tabpfn-uniform-context", action="store_true")
    args = parser.parse_args()
    if args.tabpfn_uniform_context and args.models != ["tabpfn"]:
        parser.error("Uniform context requires --models tabpfn.")
    if args.tabpfn_uniform_context and args.output_dir == Path("results/global_median_seed_0"):
        parser.error("Choose a distinct output directory for uniform context.")
    torch.set_num_threads(4)
    output = project_path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    data = PROJECT / "data/splits/seed_0"
    x, y, meta, folds = load_protocol(data, 0)
    xt, yt, mt = load_split(data, "test")
    xt, yt = xt[x.columns], yt[y.columns]
    paths = [data / name for name in ["1_train.csv", "1_test.csv", "4_train.csv", "4_test.csv"]]
    hashes = {str(p.relative_to(PROJECT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    whole = pd.concat([x, xt], ignore_index=True)
    medians = whole.median()
    if medians.isna().any():
        raise ValueError("A feature has no observed values.")
    medians.rename("median").to_csv(output / "imputation_values.csv")
    filled, filled_test = x.fillna(medians), xt.fillna(medians)
    for before, after in [(x, filled), (xt, filled_test)]:
        a, b = before.to_numpy(), after.to_numpy()
        np.testing.assert_array_equal(a[np.isfinite(a)], b[np.isfinite(a)])
        assert np.isfinite(b).all()
    settings = {
        "status": "running", "imputation": "global_250_feature_median_before_split",
        "imputation_uses_test_features": True, "imputation_uses_targets": False,
        "training_samples": len(x), "test_samples": len(xt), "features": x.shape[1],
        "targets": y.shape[1], "missing_train": int(x.isna().sum().sum()),
        "missing_test": int(xt.isna().sum().sum()), "seed": 0,
        "retuned": False, "parameters_from": "results/tuned_seed_0",
        "scaling": "unchanged_training_local", "fold_order": "author_original_train_order_no_shuffle",
    }
    def save_run():
        pd.Series(settings, name="value").rename_axis("setting").to_csv(output / "run.csv")
    settings["tabpfn_uniform_context"] = args.tabpfn_uniform_context
    run_path = output / "run.csv"
    if run_path.exists():
        previous = pd.read_csv(run_path).set_index("setting")["value"]
        if str(previous.get("tabpfn_uniform_context", "False")).lower() != str(args.tabpfn_uniform_context).lower():
            raise ValueError("Context changed; use another output directory.")
    save_run()
    checkpoint = PROJECT.parent / "pretrained/Prior-Labstabpfn_3_5/tabpfn-v3.5-20260909.safetensors"
    summaries = []
    old = pd.read_csv(PROJECT / "results/tuned_seed_0/comparison.csv").set_index("model")
    if args.tabpfn_uniform_context:
        reference = pd.read_csv(PROJECT / "results/debias_reweight_seed_0/comparison.csv").set_index("method")
        old.loc["tabpfn", ["mean_cv_r2", "r2"]] = reference.loc["tabpfn_context_uniform", ["mean_cv_r2", "r2"]].to_numpy()
    for model in args.models:
        dest = output / model
        dest.mkdir(exist_ok=True)
        params_path = PROJECT / "results/tuned_seed_0" / model / "best_parameters.csv"
        params = read_parameters(params_path)
        pd.read_csv(params_path).to_csv(dest / "parameters.csv", index=False)
        def predict(a, b, c, seed):
            if model in ["gbr", "rf"]:
                from paper_baselines import fit_predict
                return fit_predict(model, params, a, b, c, jobs=8)
            if model == "tabpfn":
                from tune_tabpfn import fit_predict
                if args.tabpfn_uniform_context:
                    a = pd.concat([a, a], ignore_index=True)
                    b = pd.concat([b, b], ignore_index=True)
                return fit_predict(params, a, b, c, model_path=checkpoint, device="cuda", seed=0)
            from tune_multitask import fit_predict
            return fit_predict(params, a, b, c, seed=seed, device="cuda",
                               members=3, max_epochs=600, patience=60)
        oof = np.full(y.shape, np.nan)
        scores = []
        assignment = meta.copy()
        assignment["fold"] = 0
        for fold, (train, valid) in enumerate(folds, 1):
            path = dest / f"fold_{fold}.npy"
            if path.exists():
                pred = np.load(path)
            else:
                pred = predict(filled.iloc[train], y.iloc[train], filled.iloc[valid], fold * 1000)
                np.save(path, pred)
            assert pred.shape == (len(valid), y.shape[1]) and np.isfinite(pred).all()
            oof[valid] = pred
            assignment.loc[valid, "fold"] = fold
            scores.append({"fold": fold, **macro_scores(y.iloc[valid].to_numpy(), pred)})
            print(model, "fold", fold, scores[-1], flush=True)
        assignment.to_csv(dest / "fold_assignments.csv", index=False)
        pd.DataFrame(scores).to_csv(dest / "fold_metrics.csv", index=False)
        np.save(dest / "oof_predictions.npy", oof)
        test_path = dest / "test_predictions.npy"
        if test_path.exists():
            pred = np.load(test_path)
        else:
            pred = predict(filled, y, filled_test, 0)
            np.save(test_path, pred)
        assert pred.shape == yt.shape and np.isfinite(pred).all()
        export_predictions(dest / "test", yt, pred, mt, np.broadcast_to(y.mean().to_numpy(), yt.shape))
        metrics = macro_scores(yt.to_numpy(), pred)
        cv = float(pd.DataFrame(scores).r2.mean())
        summaries.append({"model": model, "mean_cv_r2": cv, **metrics,
                          "previous_cv_r2": old.at[model, "mean_cv_r2"],
                          "previous_test_r2": old.at[model, "r2"],
                          "delta_cv_r2": cv-old.at[model, "mean_cv_r2"],
                          "delta_test_r2": metrics["r2"]-old.at[model, "r2"]})
        pd.DataFrame(summaries).to_csv(output / "comparison.csv", index=False)
        print("Completed", summaries[-1], flush=True)
    for p in paths:
        assert hashlib.sha256(p.read_bytes()).hexdigest() == hashes[str(p.relative_to(PROJECT))]
    pd.Series(hashes, name="sha256").to_csv(output / "source_hashes.csv")
    settings["status"] = "completed"
    save_run()
    print(pd.DataFrame(summaries).round(6).to_string(index=False), flush=True)

if __name__ == "__main__":
    main()
