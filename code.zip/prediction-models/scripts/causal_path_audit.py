from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import shortest_path

from causal_graph_stability import ancestry_checks
from tabpfn_cv import project_path
from tuning_protocol import load_protocol


def relation_reachability(matrix):
    directed=(matrix == -1) & (matrix.T == 1)
    open_endpoint=(matrix != 0) & (matrix != 1)
    distances, predecessor=shortest_path(csr_matrix(directed),directed=True,unweighted=True,return_predecessors=True)
    potential=shortest_path(csr_matrix(open_endpoint),directed=True,unweighted=True)
    return np.isfinite(distances), np.isfinite(potential), distances, predecessor


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output-dir',type=Path,default=Path('results/causal_rfci_seed_0'))
    args=parser.parse_args()
    root=project_path(args.output_dir)
    x,y,_,_=load_protocol(project_path(Path('data/splits/seed_0')))
    names=list(x.add_prefix('chemical:').columns)+list(y.add_prefix('sensory:').columns)
    base=pd.read_csv(root/'pag_endpoints.csv',index_col=0).reindex(index=names,columns=names).to_numpy()
    reachable,potential,distances,predecessor=relation_reachability(base)
    size=len(names)
    adjacency_counts=np.zeros((size,size),dtype=int)
    direction_counts=np.zeros_like(adjacency_counts)
    potential_counts=np.zeros_like(adjacency_counts)
    files=sorted((root/'stability').glob('resample_*.npz'))
    for path in files:
        with np.load(path,allow_pickle=False) as stored:
            np.testing.assert_array_equal(stored['names'],np.asarray(names))
            matrix=stored['matrix']
        a,p,_,_=relation_reachability(matrix)
        adjacency_counts += matrix != 0
        direction_counts += a
        potential_counts += p
    if not files:
        raise ValueError('No graph resamples.')
    marginal=x.apply(lambda feature: y.apply(lambda target: feature.corr(target,method='spearman')))
    records=[]
    consistent=ancestry_checks(base)
    for i,feature in enumerate(x):
        for k,target in enumerate(y):
            j=len(x.columns)+k
            chain=[]
            if reachable[i,j]:
                current=j
                while current!=i:
                    chain.append(names[current])
                    current=int(predecessor[i,current])
                    if current<0:
                        raise ValueError('Broken graph path.')
                chain.append(names[i])
                chain.reverse()
            records.append({
                'chemical':feature,'sensory':target,'spearman':marginal.loc[target,feature],
                'adjacent_in_base_graph':bool(base[i,j]!=0),
                'base_chemical_endpoint':int(base[i,j]),'base_sensory_endpoint':int(base[j,i]),
                'directed_path_in_base_graph':bool(reachable[i,j]),
                'directed_path_length':distances[i,j] if reachable[i,j] else np.nan,
                'directed_path_nodes':' -> '.join(chain),
                'open_endpoint_path_in_base_graph':bool(potential[i,j]),
                'adjacency_frequency':adjacency_counts[i,j]/len(files),
                'directed_path_frequency':direction_counts[i,j]/len(files),
                'open_endpoint_path_frequency':potential_counts[i,j]/len(files),
                'base_graph_passes_basic_ancestral_checks':consistent,
                'causal_effect_identified':False,'valid_adjustment_set_certified':False,
            })
    pd.DataFrame(records).to_csv(root/'chemical_sensory_path_audit.csv',index=False,encoding='utf-8-sig')
    print(f'Audited all {len(x.columns)*len(y.columns)} chemical-sensory pairs; no predictive input removed.',flush=True)


if __name__=='__main__':
    main()
