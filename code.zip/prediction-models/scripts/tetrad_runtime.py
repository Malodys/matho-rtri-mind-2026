from __future__ import annotations

import os
from pathlib import Path
import subprocess
import sys
import sysconfig
import tempfile


def start_tetrad():
    if os.name == 'nt':
        libraries = Path(sysconfig.get_paths()['purelib'])
        if not str(libraries).isascii():
            candidates = [Path(tempfile.gettempdir()) / 'mathorcup_causal_site']
            if os.environ.get('USERPROFILE'):
                candidates.append(Path(os.environ['USERPROFILE']) / 'AppData/Local/Temp/mathorcup_causal_site')
            alias = next((path for path in candidates if path.exists() and path.resolve() == libraries.resolve()), None)
            if alias is None:
                alias = candidates[0]
                if alias.exists():
                    raise ValueError('Runtime alias points to another environment.')
                command = "New-Item -ItemType Junction -Path '" + str(alias).replace("'", "''") + "' -Target '" + str(libraries).replace("'", "''") + "' | Out-Null"
                subprocess.run(['powershell', '-NoProfile', '-Command', command], check=True,
                               creationflags=subprocess.CREATE_NO_WINDOW)
            sys.path.insert(0, str(alias))
    from importlib.resources import files
    import jpype
    import jpype.imports
    from jdk4py import JAVA_HOME
    jar = files('pytetrad').joinpath('resources', 'tetrad-current.jar')
    if not jpype.isJVMStarted():
        library = JAVA_HOME / ('bin/server/jvm.dll' if os.name == 'nt' else 'lib/server/libjvm.so')
        jpype.startJVM(str(library), '-Xmx4g', '--enable-native-access=ALL-UNNAMED', classpath=[str(jar)])
    return Path(str(jar))
