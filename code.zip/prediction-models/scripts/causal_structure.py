from __future__ import annotations

import argparse
from contextlib import redirect_stdout
import hashlib
from math import erfc, sqrt, atanh
from importlib.metadata import version
from pathlib import Path
import sqlite3
from time import perf_counter

import numpy as np
import pandas as pd
from scipy.stats import norm, rankdata

from causallearn.utils.cit import CIT_Base, register_ci_test
from causallearn.search.ConstraintBased.FCI import fci

from tabpfn_cv import PROJECT, project_path
from tuning_protocol import data_signature, load_protocol
from causal_screen import AGGREGATES, feature_labels


class SearchBudgetExceeded(RuntimeError):
    pass


def observed_gaussian_ranks(frame):
    result = np.full(frame.shape, np.nan, dtype=float)
    for j, name in enumerate(frame.columns):
        observed = frame[name].notna().to_numpy()
        ranks = rankdata(frame.loc[observed, name], method='average')
        result[observed, j] = norm.ppf((ranks - .5) / len(ranks))
    return result


class CachedMissingFisherZ(CIT_Base):
    latest = None

    def __init__(self, data, sqlite_path=None, max_tests=500000, max_seconds=300, **kwargs):
        super().__init__(data)
        self.check_cache_method_consistent('cached_missing_fisherz', 'observed-ranks-v1')
        self.assert_input_data_is_valid(allow_nan=True)
        self.started = perf_counter()
        self.max_tests, self.max_seconds = max_tests, max_seconds
        self.new_tests, self.cached_tests, self.max_conditioning = 0, 0, 0
        self.missing = np.isnan(data)
        self.complete_columns = ~self.missing.any(axis=0)
        self.correlation = pd.DataFrame(data).corr().to_numpy()
        self.database = sqlite3.connect(str(sqlite_path) if sqlite_path else ':memory:')
        self.database.execute('CREATE TABLE IF NOT EXISTS metadata (signature TEXT)')
        signature = hashlib.sha256(np.ascontiguousarray(data).tobytes()).hexdigest()
        signature += ':' + version('numpy') + ':' + version('scipy')
        previous = self.database.execute('SELECT signature FROM metadata').fetchone()
        if previous and previous[0] != signature:
            self.database.close()
            raise ValueError('CI cache data or numerical version differs.')
        if not previous:
            self.database.execute('INSERT INTO metadata VALUES (?)', (signature,))
        self.database.execute('CREATE TABLE IF NOT EXISTS tests (key TEXT PRIMARY KEY, x INTEGER, y INTEGER, conditioning TEXT, p REAL, n INTEGER)')
        self.database.commit()
        self.pvalue_cache.update(dict(self.database.execute('SELECT key,p FROM tests')))
        CachedMissingFisherZ.latest = self

    def __call__(self, X, Y, condition_set=None):
        xs, ys, conditions, key = self.get_formatted_XYZ_and_cachekey(X, Y, condition_set)
        self.max_conditioning = max(self.max_conditioning, len(conditions))
        if perf_counter() - self.started > self.max_seconds or self.new_tests >= self.max_tests:
            self.database.commit()
            raise SearchBudgetExceeded('Full FCI stopped at the explicit computational budget; no completed PAG is claimed.')
        if key in self.pvalue_cache:
            self.cached_tests += 1
            return self.pvalue_cache[key]
        variables = xs + ys + conditions
        if self.complete_columns[variables].all() and len(conditions) <= 1:
            n = self.sample_size
            a, b = xs[0], ys[0]
            rho = self.correlation[a, b]
            if conditions:
                z = conditions[0]
                az, bz = self.correlation[a,z], self.correlation[b,z]
                denominator = (1-az*az)*(1-bz*bz)
                if denominator <= 1e-12:
                    raise ValueError('A low-order CI test is singular; no substitute p-value is produced.')
                rho = (rho-az*bz)/sqrt(denominator)
        else:
            if self.complete_columns[variables].all():
                n = self.sample_size
                correlation = self.correlation[np.ix_(variables, variables)]
            else:
                observed = ~self.missing[:, variables].any(axis=1)
                n = int(observed.sum())
                correlation = np.corrcoef(self.data[observed][:, variables].T)
            if n <= len(conditions) + 3 or not np.isfinite(correlation).all():
                raise ValueError('A CI test lacks sufficient nonconstant observed samples.')
            inverse = np.linalg.inv(correlation)
            if inverse[0,0] <= 0 or inverse[1,1] <= 0:
                raise ValueError('A CI test is numerically unidentified; no substitute p-value is produced.')
            rho = -inverse[0,1] / sqrt(inverse[0,0]*inverse[1,1])
        rho = min(max(float(rho), -1 + np.finfo(float).eps), 1 - np.finfo(float).eps)
        probability = erfc(abs(atanh(rho))*sqrt(n-len(conditions)-3)/sqrt(2))
        self.pvalue_cache[key] = probability
        self.database.execute('INSERT INTO tests VALUES (?,?,?,?,?,?)',
                              (key, xs[0], ys[0], '.'.join(map(str, conditions)), probability, n))
        self.new_tests += 1
        if self.new_tests % 2000 == 0:
            self.database.commit()
        return probability

    def close(self):
        self.database.commit()
        self.database.close()


register_ci_test('beer_missing_fisherz', CachedMissingFisherZ)


def build_joint(features, targets):
    if not features.index.equals(targets.index):
        raise ValueError('Unaligned chemical and sensory rows.')
    return pd.concat([features.add_prefix('chemical:'), targets.add_prefix('sensory:')], axis=1)


def edge_interpretation(left, right):
    if left == 1 and right == 1:
        return 'latent_common_cause_compatible'
    if (left, right) in [(-1, 1), (1, -1)]:
        return 'directed_ancestral_candidate_not_effect_estimate'
    if left == 2 and right == 2:
        return 'direction_and_confounding_unresolved'
    if (left, right) in [(2, 1), (1, 2)]:
        return 'causal_path_or_latent_confounding_unresolved'
    return 'selection_or_other_ancestral_ambiguity'


def prior_audit(a_role, b_role, at_a, at_b):
    if a_role == b_role:
        return 'no_temporal_restriction'
    at_sensory = at_a if a_role == 'sensory' else at_b
    if at_sensory == -1:
        return 'conflicts_with_sensory_not_ancestor_of_composition'
    if at_sensory == 2:
        return 'sensory_endpoint_can_be_arrow_by_prior_other_endpoint_stays_unresolved'
    return 'consistent_with_sensory_not_ancestor_of_composition'



def ancestral_consistency(matrix):
    import networkx as nx
    directed=nx.DiGraph()
    directed.add_nodes_from(range(len(matrix)))
    directed.add_edges_from(map(tuple,np.argwhere((matrix == -1) & (matrix.T == 1))))
    if not nx.is_directed_acyclic_graph(directed):
        return False
    for i,j in np.argwhere(matrix == 1):
        if nx.has_path(directed,int(i),int(j)):
            return False
    return True


def export_graph(output, graph, edges, features, targets, labels):
    names = [node.get_name() for node in graph.get_nodes()]
    expected = list(features.add_prefix('chemical:').columns) + list(targets.add_prefix('sensory:').columns)
    if len(names) != len(expected) or set(names) != set(expected):
        raise ValueError('Causal graph nodes differ from the complete joint input.')
    pd.DataFrame(graph.graph, index=names, columns=names).to_csv(
        output/'pag_endpoints.csv', encoding='utf-8-sig')
    catalog = []
    for name in names:
        role, field = name.split(':', 1)
        catalog.append({'node': name, 'role': role, 'field': field,
                        'label': labels.get(field, field) if role == 'chemical' else field,
                        'derived_aggregate': role == 'chemical' and field in AGGREGATES})
    node_catalog = pd.DataFrame(catalog)
    node_catalog.to_csv(output/'nodes.csv', index=False, encoding='utf-8-sig')
    lookup = node_catalog.set_index('node')
    rows = []
    consistent = ancestral_consistency(graph.graph)
    for edge in edges:
        a, b = edge.get_node1().get_name(), edge.get_node2().get_name()
        ea, eb = edge.get_endpoint1().value, edge.get_endpoint2().value
        properties = sorted(prop.name for prop in edge.properties)
        derived = bool(lookup.at[a, 'derived_aggregate'] or lookup.at[b, 'derived_aggregate'])
        rows.append({
            'node_a': a, 'node_b': b, 'label_a': lookup.at[a, 'label'], 'label_b': lookup.at[b, 'label'],
            'role_a': lookup.at[a, 'role'], 'role_b': lookup.at[b, 'role'],
            'endpoint_a': ea, 'endpoint_b': eb, 'edge': str(edge),
            'interpretation': edge_interpretation(ea, eb), 'algorithm_properties': '|'.join(properties),
            'involves_derived_aggregate': derived,
            'domain_prior_audit': prior_audit(lookup.at[a, 'role'], lookup.at[b, 'role'], ea, eb),
            'graph_basic_ancestral_consistency': consistent,
            'evidence': 'exploratory_under_causal_markov_faithfulness_and_test_assumptions',
        })
    table = pd.DataFrame(rows, columns=['node_a','node_b','label_a','label_b','role_a','role_b',
                                      'endpoint_a','endpoint_b','edge','interpretation','algorithm_properties',
                                      'involves_derived_aggregate','domain_prior_audit','graph_basic_ancestral_consistency','evidence'])
    table.to_csv(output/'all_relations.csv', index=False, encoding='utf-8-sig')
    table.loc[table.role_a != table.role_b].to_csv(output/'chemical_sensory_relations.csv', index=False, encoding='utf-8-sig')
    table.loc[(table.role_a == 'chemical') & (table.role_b == 'chemical')].to_csv(
        output/'chemical_relations.csv', index=False, encoding='utf-8-sig')
    table.loc[table.interpretation == 'latent_common_cause_compatible'].to_csv(
        output/'latent_confounding_candidates.csv', index=False, encoding='utf-8-sig')
    return table


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data-dir', type=Path, default=Path('data/splits/seed_0'))
    parser.add_argument('--output-dir', type=Path, default=Path('results/causal_structure_seed_0'))
    parser.add_argument('--alpha', type=float, default=.01)
    parser.add_argument('--max-tests', type=int, default=500000)
    parser.add_argument('--max-seconds', type=int, default=300)
    args = parser.parse_args()
    output = project_path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    x, y, metadata, _ = load_protocol(project_path(args.data_dir))
    joint = build_joint(x, y)
    transformed = observed_gaussian_ranks(joint)
    settings = {
        'dataset_sha256': data_signature(x,y,metadata), 'samples': len(x), 'chemical_nodes': x.shape[1],
        'sensory_nodes': y.shape[1], 'predictive_inputs_removed': 0, 'algorithm': 'FCI',
        'causal_learn': version('causal-learn'), 'alpha': args.alpha,
        'adjacency_depth': -1, 'discriminating_path_length': -1, 'background_knowledge_enforced': False,
        'background_knowledge_note': 'avoid_causal_learn_issue_266_audit_temporal_prior_separately',
        'conditional_test': 'rank_gaussian_testwise_deletion_FisherZ',
        'missingness_assumption': 'MCAR_for_testwise_deletion_not_verified',
        'faithfulness_assumption': 'not_verified_derived_aggregates_may_violate',
        'nonlinear_independence_comprehensively_tested': False,
        'causal_effects_estimated': False, 'test_samples_used': False,
    }
    run_path = output/'run.csv'
    if run_path.exists():
        previous = pd.read_csv(run_path).set_index('setting')['value']
        for key,value in settings.items():
            if str(previous.get(key)) != str(value):
                raise ValueError(f'Setting changed: {key}; choose a new output directory.')
    pd.Series({**settings,'status':'running'},name='value').rename_axis('setting').to_csv(run_path,encoding='utf-8-sig')
    metadata.to_csv(output/'training_beers.csv',index=False,encoding='utf-8-sig')
    print(f'Full joint causal discovery: {len(x)} samples, {x.shape[1]} chemical + {y.shape[1]} sensory nodes.',flush=True)
    started = perf_counter()
    status, details = 'interrupted', ''
    try:
        with (output/'algorithm.log').open('a',encoding='utf-8') as log, redirect_stdout(log):
            graph, edges = fci(transformed, independence_test_method='beer_missing_fisherz',alpha=args.alpha,
                               depth=-1,max_path_length=-1,show_progress=False,node_names=list(joint.columns),
                               sqlite_path=output/'ci_cache.sqlite',max_tests=args.max_tests,max_seconds=args.max_seconds)
        relations = export_graph(output,graph,edges,x,y,feature_labels(PROJECT))
        status='completed_exploratory'
        print(relations.groupby(['role_a','role_b','interpretation']).size().to_string(),flush=True)
    except SearchBudgetExceeded as error:
        status, details = 'budget_exhausted_no_completed_graph', str(error)
        print(details,flush=True)
    except Exception as error:
        status, details = 'failed_no_completed_graph', repr(error)
        raise
    finally:
        ci=CachedMissingFisherZ.latest
        counts = {}
        if ci is not None:
            counts={'new_ci_tests':ci.new_tests,'cached_ci_tests':ci.cached_tests,'largest_conditioning_set':ci.max_conditioning}
            ci.close()
        pd.Series({**settings,**counts,'status':status,'details':details,'seconds':perf_counter()-started},
                  name='value').rename_axis('setting').to_csv(run_path,encoding='utf-8-sig')
        print(f'Status: {status}; elapsed {perf_counter()-started:.1f}s.',flush=True)


if __name__=='__main__':
    main()
