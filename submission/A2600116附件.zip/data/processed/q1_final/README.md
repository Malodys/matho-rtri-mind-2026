# 问题一 · 数据缺失条件下的感官评分（0–6 分制分级）交付说明

> 本目录是**问题一的正式成品**。所有数字均由本机真实重跑产生，脚本入口见文末「复现命令」。
> 生成日期：2026-10-28 ｜ 模型：`independent_gbr` ｜ 数据版本：`data_contract_v1`

---

## 0. 必须先声明的前提（论文中同步出现）

1. **附件中不存在原始 0–6 分数**。`3.xlsx` 是**空白品评卡模板**（各 sheet 为待填写的评分表），
   `4.csv` 给出的 50 个感官维度是**标准化/中心化后的连续值**（mean≈0，std∈[0.37, 0.86]），
   **不是 z 分数，无法反解原始量表**。
2. 因此本问的「0–6 分制」是**本文显式构造**的分级结果，分两轨给出：
   - **主轨 · 相对分级（proxy grade）**：由**训练集**分位切点离散化得到的 0–6 整数等级；
   - **副轨 · 绝对锚定（absolute anchor）**：**基于感官阈值的一阶近似，本文提出**，
     仅在通过有效性护栏的维度上给出，**不得宣称为实测 0–6 分**。
3. 化合物矩阵已统一为 `log10(mg/L)`（`data/interim/chem_log10_matrix_v1.csv`）。
   原始 `1.csv` 是混合标度（37 列 log10、33 列存原始浓度），
   **任何环节都不得对全表做 `10**x`**；建模特征为剔除 4 个 `*_sum` 派生列后的 **227 列**。

---

## 1. 双轨分级的定义式

### 1.1 主轨 · 相对分级（proxy grade）

对每个感官维度 $d$（共 50 个）：

* **切点（训练集唯一来源）**：在 175 个训练样本上取 6 个七分位数
  $\;c_{d,1}<\dots<c_{d,6}\;\Rightarrow\;$ 7 个区间；
  **切点严禁用测试集或全量数据拟合**（信息泄漏）。
* **离散化**：$\;\text{grade}=\text{clip}\big(\#\{c_{d,k}<\text{value}\},\;0,\;6\big)$，
  真实值与预测值用**同一组**切点。
* 交付物中 `<dim>_grade` 即为该等级（整数，$0\le g\le 6$）。

### 1.2 副轨 · 绝对锚定（absolute anchor）

对每个具备化学载体的感官维度 $d$（载体列 $c$）：

1. $x_i$ = 统一矩阵中载体 $c$ 的 $\log_{10}$ 浓度；
2. **锚点 1（0 分）**：$x_{\text{thr}}=\log_{10}(\text{该维度的感知阈值，来自 8.xlsx「Sensory thresholds」）}$，
   经训练集经验分布的分位匹配换算到 $z$ 空间：$z_A=Q_z\big(F_x(x_{\text{thr}})\big)$；
3. **锚点 2（6 分）**：$x_{95}$ = 训练集载体浓度的 P95，$z_B=Q_z\big(F_x(x_{95})\big)$；
4. 由两点解仿射映射
   $$\text{raw}=a+b\,z,\qquad b=\frac{6}{z_B-z_A},\quad a=-b\,z_A;$$
5. 任一样本：$$\text{<dim>\_abs}=\operatorname{clip}\big(a+b\,\hat z,\;0,\;6\big),$$
   其中 $\hat z$ 为该维度的标准化感官值（交付表用模型的 5 折 OOF 预测；评估时用留出集预测/观测值分别代入）。

**无阈值载体的替代规则（本文已声明）**：8.xlsx 中 `CO2.PSI.`、`unfermentables`、
`X.E..2.nonenal` 无阈值数值，改用「训练集 P05 浓度 → 0 分、训练集 P95 浓度 → 6 分」的**相对约束**，
其 0 分含义是「该载体在训练集中最低的 5%」，**不是**「低于感知阈值」。

---

## 2. 有效性护栏（绝对锚定专用）

锚定只在下列条件**全部满足**时成立，否则该维度 `valid=False`、`<dim>_abs` **留空（NaN）**，
**绝不用代理分级回填**。阈值集中定义于 `scripts/q1_absolute_anchor.py` 的 `VALIDITY_RULES`。

| 规则 | 判定 | 阈值 |
| --- | --- | --- |
| 规则 1 | 载体在 8.xlsx 有感知阈值；或使用上文已声明的相对约束替代规则 | — |
| 规则 2 | 载体浓度与该感官维度的 Spearman ρ ≥ 0.30 且为正 | ρ ≥ 0.30 |
| 规则 3 | 0 分锚点对应的训练集分位 ≤ 0.60 | ≤ 0.60 |
| 规则 4 | z 锚点带宽 $z_B-z_A$ ≥ 0.50（避免映射退化成阶跃） | ≥ 0.50 |
| 规则 5 | 映射后落在 [0,6] 内的样本比例 ≥ 0.30（在训练集观测 $z$ 上评估） | ≥ 0.30 |

---

## 3. 锚定可用性总表（11 个候选维度 → 3 个通过）

数据来源：`absolute_anchor_params.csv`（逐维度 `valid` / `invalid_reason` / 覆盖率列）。
`ρ` = 载体浓度与标准化感官值的 Spearman；`F0` = 0 分锚点对应的训练集分位；
`带宽` = $z_B-z_A$；`[0,6]内` = 训练集观测 $z$ 上落入区间的样本比例。

### 3.1 通过护栏（3 个维度，其 `<dim>_abs` 有值）

| 维度 | 载体 | 锚定方式 | 阈值 → log10 阈值 | ρ | F0 | 带宽 | [0,6]内 | OOF 覆盖 |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: |
| `bitternes` | `bitterness` | 阈值锚定 | 5 IBU → 0.6990 | +0.6558 | 0.143 | 2.052 | 0.806 | 0.888 |
| `alcohol` | `ethanol..v.v.` | 阈值锚定 | 1.75726 v/v → 0.2448 | +0.8130 | 0.023 | 2.957 | 0.926 | 0.980 |
| `co2` | `CO2.PSI.` | 相对约束替代规则 | 无阈值 | +0.4668 | 0.050 | 1.869 | 0.891 | 1.000 |

### 3.2 未通过（8 个维度，`<dim>_abs` 留空）

| 维度 | 载体 | 阈值 → log10 阈值 | ρ | 不合格原因（归类） |
| --- | --- | --- | ---: | --- |
| `dms` | `DMS` | 17.25 µg/L → −1.7632 | +0.0875 | **无信号**（规则2：ρ=0.0875<0.30） |
| `diacetyl` | `X2.3.butanedione` | 0.29925 mg/L → −0.5240 | −0.0964 | **方向相反**（规则2：ρ=−0.0964<0.30） |
| `t2n` | `X.E..2.nonenal` | 无阈值 | −0.2400 | **方向相反**（规则2：ρ=−0.2400<0.30） |
| `sweetness` | `unfermentables` | 无阈值 | +0.1803 | **无信号**（规则2：ρ=0.1803<0.30） |
| `metallic` | `iron` | 0.1 mg/L → −1.0000 | +0.2705 | **无信号**（规则2：ρ=0.2705<0.30） |
| `body` | `protein.g.L.` | 1.02393 g/L → 0.0103 | +0.2729 | **无信号**（规则2：ρ=0.2729<0.30） |
| `X4vg` | `X4VG` | 0.206333 mg/L → −0.6854 | +0.5073 | **退化**（规则3：F0=0.926>0.60；规则4：带宽=0.440<0.50；规则5：[0,6]内=0.023<0.30） |
| `acidity` | `lactic_acid.mg.L.` | 416.667 mg/L → 2.6198 | +0.3027 | **退化**（规则3：F0=0.823>0.60；规则5：[0,6]内=0.126<0.30） |

> **敏感性说明**：`metallic`（ρ=0.2705）与 `body`（ρ=0.2729）仅以「未达 ρ≥0.30」一条落榜；
> 若把规则 2 放宽到 ρ≥0.25，二者亦可通过。本文**不采用**该放宽版本，以免为凑覆盖面而移动判据。
>
> **结论必须如实写出**：绝对锚定副轨**只对 11 个候选维度中的 3 个成立**，且其中 1 个（`co2`）
> 走的是相对约束替代规则而非真实感知阈值；对 dms / diacetyl / t2n / X4vg 等缺陷维度**不适用**。

---

## 4. 评估口径

* **切分**：`data/splits/seed_0`，按 `tasting_category_fine` 分层，**175 训练 / 75 留出**，seed 0。
* **特征**：统一 log10(mg/L) 矩阵 250×227（剔除 4 个 `*_sum` 派生列）；风格标签**未**作为特征。
* **指标**：按 50 个感官维度分别计算后取平均（等权），与 `scripts/q1_evaluation.py` 完全一致。
* **两轨指标**：
  * 主轨：等级 MAE / 精确准确率 / 相邻一级准确率 / QWK（`proxy_*`）；
  * 副轨：仅在**通过护栏**的 3 个维度上评估绝对分 MAE / 精确准确率 / 相邻一级准确率 / QWK（`abs_*`）。
* **bootstrap**：2000 次**配对**重采样（同一组行索引作用于全部模型），报告 Macro-RMSE 的
  95% 置信区间、模型两两差值区间与「区间是否重叠」。
* **交付表中的 `<dim>_pred`**：250 个样本上 **5 折 OOF（seed 0）** 预测，
  避免「用留出集拟合后再自评」；所有**对外报告的指标**均来自锁定的 175/75 留出集。
* **泄漏检查**：`scripts/q1_leakage_check.py` 断言切点与锚点仅由 175 个训练样本产生，
  并反证「交付切点 ≠ 测试集拟合切点 ≠ 全量拟合切点」。

### 4.1 模型对比（留出集 75 样本，bootstrap 2000 次）

| 模型 | Macro-RMSE | 95% CI | R² 中位 | Spearman 中位 | 等级 MAE | 精确准确率 | 相邻一级准确率 | QWK | 优于基线 |
| --- | ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: | :---: |
| `independent_gbr` | **0.4880** | [0.4473, 0.5199] | 0.1833 | 0.3819 | 1.6085 | 0.2067 | 0.5397 | 0.3048 | ✅ |
| `grouped_extra_trees` | 0.4881 | [0.4467, 0.5200] | 0.1883 | 0.4164 | 1.6056 | 0.2040 | 0.5336 | 0.2941 | ✅ |
| `global_extra_trees` | 0.4893 | [0.4488, 0.5194] | 0.1652 | 0.4112 | 1.6115 | 0.2056 | 0.5304 | 0.2787 | ✅ |
| `pls2` | 0.4915 | [0.4560, 0.5183] | 0.1766 | 0.4033 | 1.6067 | 0.2141 | 0.5488 | 0.3459 | ✅ |
| `multitask_elastic_net` | 0.4929 | [0.4537, 0.5220] | 0.1422 | 0.4143 | 1.6165 | 0.1955 | 0.5333 | 0.2996 | ✅ |
| `ridge` | 0.4976 | [0.4599, 0.5269] | 0.1766 | 0.3669 | 1.6245 | 0.2027 | 0.5320 | 0.3105 | ✅ |
| `global_mean`（基线） | 0.5762 | [0.5309, 0.6131] | −0.0066 | — | 1.8792 | 0.1547 | 0.4280 | 0.0000 | ❌ |

**结论表述（论文必须照此口径）**：六个候选模型的 95% 置信区间**两两高度重叠**
（42 个有序模型对中 30 个区间重叠；**非基线的 6 个模型之间 30/30 全部重叠**，
12 个不重叠的有序对全部涉及全局均值基线；与 `independent_gbr` 的差值区间均跨 0，
如 `grouped_extra_trees` 差值 +0.0001、CI [−0.0066, +0.0061]），
**因此不得依据 0.001 量级的 Macro-RMSE 差距宣称某模型显著更优**；
最终选用 `independent_gbr` 仅因其 Macro-RMSE 点估计最低、且逐维调参后仍稳定，
**模型间的优劣在统计上不可区分**。唯一显著的差异是「所有模型均显著优于全局均值基线」：
六个模型与基线的差值区间**全部落在 0 以下**
（`independent_gbr` −0.0883 [−0.1068, −0.0685]，最弱的 `ridge` −0.0786 [−0.0956, −0.0608]）。

### 4.2 副轨（绝对锚定）在 3 个有效维度上的表现

| 维度 | 锚定方式 | 绝对分 MAE | 精确准确率 | 相邻一级准确率 | QWK |
| --- | --- | ---: | ---: | ---: | ---: |
| `bitternes` | 阈值锚定 | 0.799 | 0.440 | 0.840 | 0.795 |
| `alcohol` | 阈值锚定 | 0.573 | 0.467 | 0.933 | 0.789 |
| `co2` | 相对约束替代规则 | 1.155 | 0.240 | 0.693 | 0.489 |
| **三维有效均值** | — | **0.842** | **0.382** | **0.822** | **0.691** |

`model_summary.csv` 同时保存 `abs_threshold_*`（阈值锚定 2 维）、
`abs_fallback_*`（相对约束替代 1 维）与 `abs_valid_*`（3 维有效均值）。
兼容字段 `abs_*` 等于 `abs_valid_*`，不得用 fallback 子集代替三维汇总。

---

## 5. 交付物清单

| 文件 | 内容 |
| --- | --- |
| `sensory_scores_0_6.csv` | **正式成品**：250 行 × 153 列（3 键列 + 50 维 × `pred`/`grade`/`abs`） |
| `model_summary.csv` | 7 个模型 × 连续指标 + 两轨分级指标 + bootstrap 区间；绝对轨按阈值、fallback、valid 三组汇总 |
| `proxy_grade_cutpoints.csv` | 50 个维度的 6 个训练集分位切点（`boundary_1..6`） |
| `absolute_anchor_params.csv` | 11 个候选维度的载体、阈值、log10 阈值、P95 锚点、a/b、ρ、覆盖率、`valid`、`invalid_reason` |
| `absolute_grade_metrics_by_label.csv` | 通过护栏维度的副轨逐维指标 |
| `bootstrap_macro_rmse.csv` / `bootstrap_model_differences.csv` / `bootstrap_ci_overlap.csv` | bootstrap 区间、两两差值与区间重叠判定 |
| `test_predictions.csv.gz` | 7 个模型 × 75 留出样本 × 50 维的连续值与两轨等级 |
| `model_independent_gbr.joblib` + `model_independent_gbr_metadata.json` | 供问题三调用的模型工件（全 250 样本重训）与特征列序元数据 |
| `run_config.json` | 本次运行的模型清单、最优模型、bootstrap 次数、锚定护栏阈值 |

图表在 `data/processed/q1_figures/`：
`01_model_comparison_bootstrap_ci.png`（模型对比点图带 bootstrap CI）、
`02_dimension_predictability_facets.png`（逐维可预测性分面图）、
`03_two_track_grade_comparison.png`（两轨分级对照图）、
`04_absolute_anchor_calibration.png`（绝对锚定标定图）。

---

## 6. 对外推理接口（供问题三调用）

```python
from q1_predict import predict_sensory
scores = predict_sensory(compound_matrix)            # 231 列（含 *_sum）自动剔除
scores = predict_sensory(compound_matrix, "ridge")    # 也可指定其它模型
```

* 输入：统一 log10(mg/L) 化合物矩阵，索引为 beer；输出：索引一致、50 列标准化预测值。
* 工件 `model_independent_gbr.joblib` 在**全部 250 样本**上重训；
  交付表 `sensory_scores_0_6.csv` 中的 `<dim>_pred` 来自 **5 折 OOF**，
  **两者口径不同、不可混用**（自检：`.venv\Scripts\python.exe scripts/q1_predict.py --self-test`）。

---

## 7. 复现命令

```powershell
# 1) 七模型族重跑 + 双轨分级 + bootstrap + 交付物（约 25–35 分钟，CPU）
$env:JOBLIB_CPU_COUNT="8"
.\.venv\Scripts\python.exe scripts/q1_pipeline.py `
    --runs-dir data/processed/q1_runs --output-dir data/processed/q1_final --n-boot 2000

# 1b) 复用已有模型运行、只重算交付物（数分钟）
.\.venv\Scripts\python.exe scripts/q1_pipeline.py --skip-fit --n-boot 2000

# 2) 图表
.\.venv\Scripts\python.exe scripts/q1_figures.py

# 3) 泄漏检查
.\.venv\Scripts\python.exe scripts/q1_leakage_check.py

# 4) 单元测试（问题一新增测试 + 队友测试全绿）
.\.venv\Scripts\python.exe -m pytest tests_q1 -q
.\.venv\Scripts\python.exe -m pytest worktrees/prediction-models/tests -q

# 5) TabPFN 3.5 五折复现（主控执行，含断点续跑）
.\.venv\Scripts\python.exe scripts/q1_tabpfn_cv.py --workers 4 --threads 2 --resume `
    --output-dir data/processed/q1_repro_tabpfn

# 5b) 公平协议对照（227 统一特征 + 固定 175/75 留出；需单独运行，结果不覆盖 5）
.\.venv\Scripts\python.exe scripts/q1_tabpfn_cv.py --protocol fair_main --workers 4 --threads 2 --resume `
    --output-dir data/processed/q1_fair_tabpfn
```

---

## 8. 已知局限

1. **0–6 分制是本文构造的，不是实测分数**：附件无原始分制（`3.xlsx` 为空白品评卡模板、
   `4.csv` 为标准化值），因此主轨等级只保证**样本间的相对次序**，不可与外部绝对评分直接比较。
2. **主轨切点依赖训练集**：切点由 175 个训练样本的七分位数给出，换切分或换数据集，
   等级刻度会随之变化，跨研究比较须声明切点来源。
3. **副轨覆盖面很窄**：11 个候选维度中仅 3 个通过有效性护栏，对 **dms / diacetyl / t2n / X4vg /
   acidity / sweetness / metallic / body 均不适用**；缺陷维度在本数据上「化合物浓度 ↔ 感官强度」
   的关系太弱或方向相反，硬做绝对锚定会产出误导性分数。
4. **副轨是阈值锚定的一阶近似**：用「载体浓度的经验分位 ↔ 标准化感官值的经验分位」匹配来换算锚点，
   隐含「感官强度随载体浓度单调」且「分位可一一对应」两条假设；
   `co2` 更是只满足相对约束，其 0 分并不代表「不可察觉」。
5. **模型性能上限有限**：留出集 Macro-RMSE ≈ 0.49、Spearman 中位 ≈ 0.38–0.42，
   感官目标本身含较大不可解释方差（品评噪声），模型只能解释小部分。
6. **模型间不可区分**：bootstrap 置信区间高度重叠，不支持「某模型更优」的结论。
7. **交付表 `<dim>_pred` 是 OOF 预测**，与工件（全量重训）口径不同；
   `_abs` 列在不合格维度上**为空**，任何下游脚本须先读 `absolute_anchor_params.csv` 的 `valid` 列。
8. **TabPFN 复现由主控单独执行**（本目录脚本不负责该进程）。
